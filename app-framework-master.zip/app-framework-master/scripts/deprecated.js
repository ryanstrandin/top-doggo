/* Purpose: Inform user about deprecated scripts */

let alert = require('./alert')

alert('The script you have called is deprecated.\nPlease check our documentation on GitHub.')
