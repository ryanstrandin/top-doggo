<template>
  <div>
    <f7-popup id="app-framework-login-popup" tablet-fullscreen :opened="true" style="left: 100%">
      <f7-view url="/app-framework-login-screen/" />
    </f7-popup>
  </div>
</template>
