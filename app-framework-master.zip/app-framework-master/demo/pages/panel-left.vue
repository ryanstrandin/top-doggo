<template>
  <f7-page>
    <f7-navbar title="Left Panel"></f7-navbar>
    <f7-block inner>
      <p>Left panel content goes here</p>
    </f7-block>
  </f7-page>
</template>
