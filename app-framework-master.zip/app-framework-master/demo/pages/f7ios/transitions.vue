<template>
  <div data-page="transitions" class="page kitchen-sink-ios">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left sliding"><a class="back link" href="#"><i class="icon icon-back"></i><span>Back</span></a></div>
        <div class="center sliding">Transitions</div>
      </div>
    </div>
    <div class="page-content">
      <div class="content-block-title">Pages Animation</div>
      <div class="content-block">
        <div class="content-block-inner">
          <p>One of the main target of Framework7 is to have native look and feeling of iOS application. And Framework7 is the only framework that solves it and offers 1:1 page animation with smooth parallax effect, changing opacity and shadow when loading
            new page.</p>
        </div>
      </div>
      <div class="content-block-title">Swipe Back</div>
      <div class="content-block">
        <div class="content-block-inner">
          <p>One of Framework7' killing feature is supporting of iOS well known swipe back gesture from left border of screen when you want to get to the previous page. It simply works, and works perfectly as you expect it to do. Just swipe from left (or drag
            with mouse) area of the page to see smooth transition to the previous page. It is not just A-B transition. It really follows your finger with parallax animation while touch!</p>
        </div>
      </div>
      <div class="content-block-title">Dynamic Navbar</div>
      <div class="content-block">
        <div class="content-block-inner">
          <p>As was mentioned already Framework7 makes everything to give you a feel of native iOS app. And one of the significant feature that improves this feeling is the dynamic navigation bar (navbar). You can see how its elements sliding and fading during
            pages transition and when you swipe back.</p>
        </div>
      </div>
    </div>
  </div>
</template>
