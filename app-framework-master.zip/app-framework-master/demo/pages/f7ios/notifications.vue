<template>
  <div data-page="notifications" class="page kitchen-sink-ios">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left sliding"><a class="back link" href="#"><i class="icon icon-back"></i><span>Back</span></a></div>
        <div class="center sliding">Notifications</div>
      </div>
    </div>
    <div class="page-content">
      <div class="content-block">
        <p>Framework7 comes with simple Notifications component that allows you to show some useful messages to user.</p>
        <p><a href="#" class="button ks-notification-simple">Default notification</a></p>
        <p><a href="#" class="button ks-notification-full">Full-layout notification</a></p>
        <p><a href="#" class="button ks-notification-custom">With custom image</a></p>
        <p><a href="#" class="button ks-notification-callback">With callback on close</a></p>
      </div>
    </div>
  </div>
</template>
