<template>
  <div data-page="hide-navbar-toolbar" class="page kitchen-sink-ios">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left sliding"><a class="back link" href="#"><i class="icon icon-back"></i><span>Back</span></a></div>
        <div class="center sliding">Hide Navbar &amp; Toolbar</div>
      </div>
    </div>
    <div class="page-content">
      <div class="content-block">
        <div class="content-block-inner">
          <p>Sometimes you may need to hide top Navbar or bottom Toolbar. Framework7 allows this by adding additional classes to pages. Check examples:</p>
        </div>
      </div>
      <div class="list-block">
        <ul>
          <li>
            <a href="/f7ios/bars-no-navbar/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Hide Navbar</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/bars-no-toolbar/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Hide Toolbar</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/bars-no-navbar-toolbar/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Hide Both</div>
                </div>
              </div>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
