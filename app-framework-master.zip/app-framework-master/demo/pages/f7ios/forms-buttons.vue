<template>
  <div data-page="form-buttons" class="page kitchen-sink-ios">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left sliding"><a class="back link" href="#"><i class="icon icon-back"></i><span>Back</span></a></div>
        <div class="center sliding">Buttons</div>
      </div>
    </div>
    <div class="page-content">
      <div class="content-block-title">Usual Buttons</div>
      <div class="content-block">
        <div class="row">
          <div class="col-33"><a href="#" class="button active">Active</a></div>
          <div class="col-33"><a href="#" class="button">Button</a></div>
          <div class="col-33"><a href="#" class="button button-round">Round</a></div>
        </div>
      </div>
      <div class="content-block">
        <div class="row">
          <div class="col-50"><a href="#" class="button active">Active</a></div>
          <div class="col-50"><a href="#" class="button">Button</a></div>
        </div>
      </div>
      <div class="content-block">
        <div class="buttons-row"><a href="#" class="button">Button</a><a href="#" class="button">Button</a></div>
      </div>
      <div class="content-block">
        <div class="buttons-row"><a href="#" class="button button-round">Button</a><a href="#" class="button button-round">Button</a><a href="#" class="button button-round">Button</a></div>
      </div>
      <div class="content-block">
        <div class="buttons-row"><a href="#" class="button">Button</a><a href="#" class="button active">Button</a><a href="#" class="button">Button</a><a href="#" class="button">Button</a></div>
      </div>
      <div class="content-block-title">Big Buttons</div>
      <div class="content-block">
        <div class="row">
          <div class="col-50"><a href="#" class="button button-big active">Active</a></div>
          <div class="col-50"><a href="#" class="button button-big">Button</a></div>
        </div>
      </div>
      <div class="content-block-title">Themed Fill Buttons</div>
      <div class="content-block">
        <div class="row">
          <div class="col-50"><a href="#" class="button button-big button-fill color-green">Submit</a></div>
          <div class="col-50"><a href="#" class="button button-big button-fill color-red">Cancel</a></div>
        </div>
      </div>
      <div class="content-block-title">List-Block Buttons</div>
      <div class="list-block inset">
        <ul>
          <li><a href="#" class="list-button item-link">List Button 1</a></li>
          <li><a href="#" class="list-button item-link">List Button 2</a></li>
          <li><a href="#" class="list-button item-link">List Button 2</a></li>
        </ul>
      </div>
      <div class="list-block inset">
        <ul>
          <li><a href="#" class="list-button item-link color-red">Big Red Button</a></li>
        </ul>
      </div>
    </div>
  </div>
</template>
