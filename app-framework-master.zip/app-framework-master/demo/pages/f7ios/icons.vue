<template>
  <div data-page="icons" class="page kitchen-sink-ios">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left sliding"><a class="back link" href="#"><i class="icon icon-back"></i><span>Back</span></a></div>
        <div class="center sliding">Icons</div>
      </div>
    </div>
    <div class="page-content">
      <div class="content-block">
        <div class="content-block-inner">
          <p>Framework7 comes with the premium and free <a href="https://github.com/nolimits4web/Framework7-Icons" class="external" target="_blank">Framework7 Icons</a> iOS-icons font developed specially to be used with iOS theme of Framework7. As for Material
            theme we recommend to use great-designed <a href="https://material.io/icons/" class="external" target="_blank">Material Icons</a> font. Both of these fonts use a typographic feature called <a href="http://alistapart.com/article/the-era-of-symbol-fonts"
              class="external" target="_blank">ligatures</a>. It’s easy to incorporate icons into your app. Here’s a small example:</p>
          <p><code>&lt;i class="f7-icons"&gt;home&lt;/i&gt;</code> - <i class="f7-icons">home</i></p>
          <p><a href="http://alistapart.com/article/the-era-of-symbol-fonts" class="external" target="_blank">Ligatures</a> allow rendering of an icon glyph simply by using its textual name. The replacement is done automatically by the web browser and provides
            more readable code than the equivalent numeric character reference.</p>
          <p>With ligatures it is also possible to combine icons like:</p>
          <p><code>&lt;i class="f7-icons"&gt;person&lt;sup&gt;add&lt;/sup&gt;&lt;/i&gt;</code> - <i class="f7-icons">person<sup>add</sup></i></p>
        </div>
      </div>
      <div class="content-block-title">iOS Icons Set (258)</div>
      <div class="content-block">
        <div class="content-block-inner">
          <div class="row">
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">add</i></div>
              <div class="icon-name">add</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">add_round</i></div>
              <div class="icon-name">add_round</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">add_round_fill</i></div>
              <div class="icon-name">add_round_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">alarm</i></div>
              <div class="icon-name">alarm</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">alarm_fill</i></div>
              <div class="icon-name">alarm_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">albums</i></div>
              <div class="icon-name">albums</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">albums_fill</i></div>
              <div class="icon-name">albums_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">arrow_down</i></div>
              <div class="icon-name">arrow_down</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">arrow_down_fill</i></div>
              <div class="icon-name">arrow_down_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">arrow_left</i></div>
              <div class="icon-name">arrow_left</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">arrow_left_fill</i></div>
              <div class="icon-name">arrow_left_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">arrow_right</i></div>
              <div class="icon-name">arrow_right</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">arrow_right_fill</i></div>
              <div class="icon-name">arrow_right_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">arrow_up</i></div>
              <div class="icon-name">arrow_up</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">arrow_up_fill</i></div>
              <div class="icon-name">arrow_up_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">at</i></div>
              <div class="icon-name">at</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">at_fill</i></div>
              <div class="icon-name">at_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">bag</i></div>
              <div class="icon-name">bag</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">bag_fill</i></div>
              <div class="icon-name">bag_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">bars</i></div>
              <div class="icon-name">bars</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">bell</i></div>
              <div class="icon-name">bell</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">bell_fill</i></div>
              <div class="icon-name">bell_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">bolt</i></div>
              <div class="icon-name">bolt</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">bolt_fill</i></div>
              <div class="icon-name">bolt_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">bolt_round</i></div>
              <div class="icon-name">bolt_round</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">bolt_round_fill</i></div>
              <div class="icon-name">bolt_round_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">book</i></div>
              <div class="icon-name">book</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">book_fill</i></div>
              <div class="icon-name">book_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">bookmark</i></div>
              <div class="icon-name">bookmark</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">bookmark_fill</i></div>
              <div class="icon-name">bookmark_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">box</i></div>
              <div class="icon-name">box</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">box_fill</i></div>
              <div class="icon-name">box_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">briefcase</i></div>
              <div class="icon-name">briefcase</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">briefcase_fill</i></div>
              <div class="icon-name">briefcase_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">calendar</i></div>
              <div class="icon-name">calendar</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">calendar_fill</i></div>
              <div class="icon-name">calendar_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">camera</i></div>
              <div class="icon-name">camera</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">camera_fill</i></div>
              <div class="icon-name">camera_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">card</i></div>
              <div class="icon-name">card</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">card_fill</i></div>
              <div class="icon-name">card_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">chat</i></div>
              <div class="icon-name">chat</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">chat_fill</i></div>
              <div class="icon-name">chat_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">chats</i></div>
              <div class="icon-name">chats</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">chats_fill</i></div>
              <div class="icon-name">chats_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">check</i></div>
              <div class="icon-name">check</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">check_round</i></div>
              <div class="icon-name">check_round</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">check_round_fill</i></div>
              <div class="icon-name">check_round_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">chevron_down</i></div>
              <div class="icon-name">chevron_down</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">chevron_left</i></div>
              <div class="icon-name">chevron_left</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">chevron_right</i></div>
              <div class="icon-name">chevron_right</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">chevron_up</i></div>
              <div class="icon-name">chevron_up</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">circle</i></div>
              <div class="icon-name">circle</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">circle_fill</i></div>
              <div class="icon-name">circle_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">circle_half</i></div>
              <div class="icon-name">circle_half</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">close</i></div>
              <div class="icon-name">close</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">close_round</i></div>
              <div class="icon-name">close_round</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">close_round_fill</i></div>
              <div class="icon-name">close_round_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">cloud</i></div>
              <div class="icon-name">cloud</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">cloud_download</i></div>
              <div class="icon-name">cloud_download</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">cloud_download_fill</i></div>
              <div class="icon-name">cloud_download_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">cloud_fill</i></div>
              <div class="icon-name">cloud_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">cloud_upload</i></div>
              <div class="icon-name">cloud_upload</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">cloud_upload_fill</i></div>
              <div class="icon-name">cloud_upload_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">collection</i></div>
              <div class="icon-name">collection</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">collection_fill</i></div>
              <div class="icon-name">collection_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">compass</i></div>
              <div class="icon-name">compass</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">compass_fill</i></div>
              <div class="icon-name">compass_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">compose</i></div>
              <div class="icon-name">compose</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">compose_fill</i></div>
              <div class="icon-name">compose_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">data</i></div>
              <div class="icon-name">data</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">data_fill</i></div>
              <div class="icon-name">data_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">delete</i></div>
              <div class="icon-name">delete</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">delete_round</i></div>
              <div class="icon-name">delete_round</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">delete_round_fill</i></div>
              <div class="icon-name">delete_round_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">document</i></div>
              <div class="icon-name">document</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">document_fill</i></div>
              <div class="icon-name">document_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">document_text</i></div>
              <div class="icon-name">document_text</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">document_text_fill</i></div>
              <div class="icon-name">document_text_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">down</i></div>
              <div class="icon-name">down</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">download</i></div>
              <div class="icon-name">download</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">download_fill</i></div>
              <div class="icon-name">download_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">download_round</i></div>
              <div class="icon-name">download_round</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">download_round_fill</i></div>
              <div class="icon-name">download_round_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">drawer</i></div>
              <div class="icon-name">drawer</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">drawer_fill</i></div>
              <div class="icon-name">drawer_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">drawers</i></div>
              <div class="icon-name">drawers</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">drawers_fill</i></div>
              <div class="icon-name">drawers_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">email</i></div>
              <div class="icon-name">email</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">email_fill</i></div>
              <div class="icon-name">email_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">eye</i></div>
              <div class="icon-name">eye</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">eye_fill</i></div>
              <div class="icon-name">eye_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">fastforward</i></div>
              <div class="icon-name">fastforward</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">fastforward_fill</i></div>
              <div class="icon-name">fastforward_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">fastforward_round</i></div>
              <div class="icon-name">fastforward_round</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">fastforward_round_fill</i></div>
              <div class="icon-name">fastforward_round_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">favorites</i></div>
              <div class="icon-name">favorites</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">favorites_fill</i></div>
              <div class="icon-name">favorites_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">film</i></div>
              <div class="icon-name">film</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">film_fill</i></div>
              <div class="icon-name">film_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">filter</i></div>
              <div class="icon-name">filter</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">filter-fill</i></div>
              <div class="icon-name">filter-fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">flag</i></div>
              <div class="icon-name">flag</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">flag_fill</i></div>
              <div class="icon-name">flag_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">folder</i></div>
              <div class="icon-name">folder</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">folder_fill</i></div>
              <div class="icon-name">folder_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">forward</i></div>
              <div class="icon-name">forward</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">forward_fill</i></div>
              <div class="icon-name">forward_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">gear</i></div>
              <div class="icon-name">gear</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">gear_fill</i></div>
              <div class="icon-name">gear_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">graph_round</i></div>
              <div class="icon-name">graph_round</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">graph_round_fill</i></div>
              <div class="icon-name">graph_round_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">graph_square</i></div>
              <div class="icon-name">graph_square</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">graph_square_fill</i></div>
              <div class="icon-name">graph_square_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">heart</i></div>
              <div class="icon-name">heart</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">heart_fill</i></div>
              <div class="icon-name">heart_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">help</i></div>
              <div class="icon-name">help</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">help_fill</i></div>
              <div class="icon-name">help_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">home</i></div>
              <div class="icon-name">home</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">home_fill</i></div>
              <div class="icon-name">home_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">images</i></div>
              <div class="icon-name">images</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">images_fill</i></div>
              <div class="icon-name">images_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">info</i></div>
              <div class="icon-name">info</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">info_fill</i></div>
              <div class="icon-name">info_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">keyboard</i></div>
              <div class="icon-name">keyboard</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">keyboard_fill</i></div>
              <div class="icon-name">keyboard_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">layers</i></div>
              <div class="icon-name">layers</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">layers_fill</i></div>
              <div class="icon-name">layers_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">left</i></div>
              <div class="icon-name">left</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">list</i></div>
              <div class="icon-name">list</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">list_fill</i></div>
              <div class="icon-name">list_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">lock</i></div>
              <div class="icon-name">lock</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">lock_fill</i></div>
              <div class="icon-name">lock_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">login</i></div>
              <div class="icon-name">login</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">login_fill</i></div>
              <div class="icon-name">login_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">logout</i></div>
              <div class="icon-name">logout</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">logout_fill</i></div>
              <div class="icon-name">logout_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">menu</i></div>
              <div class="icon-name">menu</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">mic</i></div>
              <div class="icon-name">mic</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">mic_fill</i></div>
              <div class="icon-name">mic_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">money_dollar</i></div>
              <div class="icon-name">money_dollar</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">money_dollar_fill</i></div>
              <div class="icon-name">money_dollar_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">money_euro</i></div>
              <div class="icon-name">money_euro</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">money_euro_fill</i></div>
              <div class="icon-name">money_euro_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">money_pound</i></div>
              <div class="icon-name">money_pound</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">money_pound_fill</i></div>
              <div class="icon-name">money_pound_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">money_rubl</i></div>
              <div class="icon-name">money_rubl</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">money_rubl_fill</i></div>
              <div class="icon-name">money_rubl_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">money_yen</i></div>
              <div class="icon-name">money_yen</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">money_yen_fill</i></div>
              <div class="icon-name">money_yen_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">more</i></div>
              <div class="icon-name">more</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">more_fill</i></div>
              <div class="icon-name">more_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">more_round</i></div>
              <div class="icon-name">more_round</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">more_round_fill</i></div>
              <div class="icon-name">more_round_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">more_vertical</i></div>
              <div class="icon-name">more_vertical</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">more_vertical_fill</i></div>
              <div class="icon-name">more_vertical_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">more_vertical_round</i></div>
              <div class="icon-name">more_vertical_round</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">more_vertical_round_fill</i></div>
              <div class="icon-name">more_vertical_round_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">navigation</i></div>
              <div class="icon-name">navigation</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">navigation_fill</i></div>
              <div class="icon-name">navigation_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">paper_plane</i></div>
              <div class="icon-name">paper_plane</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">paper_plane_fill</i></div>
              <div class="icon-name">paper_plane_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">pause</i></div>
              <div class="icon-name">pause</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">pause_fill</i></div>
              <div class="icon-name">pause_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">pause_round</i></div>
              <div class="icon-name">pause_round</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">pause_round_fill</i></div>
              <div class="icon-name">pause_round_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">person</i></div>
              <div class="icon-name">person</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">person_fill</i></div>
              <div class="icon-name">person_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">persons</i></div>
              <div class="icon-name">persons</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">persons_fill</i></div>
              <div class="icon-name">persons_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">phone</i></div>
              <div class="icon-name">phone</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">phone_fill</i></div>
              <div class="icon-name">phone_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">phone_round</i></div>
              <div class="icon-name">phone_round</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">phone_round_fill</i></div>
              <div class="icon-name">phone_round_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">photos</i></div>
              <div class="icon-name">photos</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">photos_fill</i></div>
              <div class="icon-name">photos_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">pie</i></div>
              <div class="icon-name">pie</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">pie_fill</i></div>
              <div class="icon-name">pie_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">play</i></div>
              <div class="icon-name">play</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">play_fill</i></div>
              <div class="icon-name">play_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">play_round</i></div>
              <div class="icon-name">play_round</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">play_round_fill</i></div>
              <div class="icon-name">play_round_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">radio</i></div>
              <div class="icon-name">radio</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">redo</i></div>
              <div class="icon-name">redo</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">refresh</i></div>
              <div class="icon-name">refresh</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">refresh_round</i></div>
              <div class="icon-name">refresh_round</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">refresh_round_fill</i></div>
              <div class="icon-name">refresh_round_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">reload</i></div>
              <div class="icon-name">reload</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">reload_round</i></div>
              <div class="icon-name">reload_round</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">reload_round_fill</i></div>
              <div class="icon-name">reload_round_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">reply</i></div>
              <div class="icon-name">reply</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">reply_fill</i></div>
              <div class="icon-name">reply_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">rewind</i></div>
              <div class="icon-name">rewind</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">rewind_fill</i></div>
              <div class="icon-name">rewind_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">rewind_round</i></div>
              <div class="icon-name">rewind_round</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">rewind_round_fill</i></div>
              <div class="icon-name">rewind_round_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">right</i></div>
              <div class="icon-name">right</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">search</i></div>
              <div class="icon-name">search</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">search_strong</i></div>
              <div class="icon-name">search_strong</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">settings</i></div>
              <div class="icon-name">settings</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">settings_fill</i></div>
              <div class="icon-name">settings_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">share</i></div>
              <div class="icon-name">share</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">share_fill</i></div>
              <div class="icon-name">share_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">social_facebook</i></div>
              <div class="icon-name">social_facebook</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">social_facebook_fill</i></div>
              <div class="icon-name">social_facebook_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">social_github</i></div>
              <div class="icon-name">social_github</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">social_github_fill</i></div>
              <div class="icon-name">social_github_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">social_googleplus</i></div>
              <div class="icon-name">social_googleplus</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">social_instagram</i></div>
              <div class="icon-name">social_instagram</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">social_instagram_fill</i></div>
              <div class="icon-name">social_instagram_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">social_linkedin</i></div>
              <div class="icon-name">social_linkedin</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">social_linkedin_fill</i></div>
              <div class="icon-name">social_linkedin_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">social_rss</i></div>
              <div class="icon-name">social_rss</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">social_rss_fill</i></div>
              <div class="icon-name">social_rss_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">social_twitter</i></div>
              <div class="icon-name">social_twitter</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">social_twitter_fill</i></div>
              <div class="icon-name">social_twitter_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">sort</i></div>
              <div class="icon-name">sort</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">sort_fill</i></div>
              <div class="icon-name">sort_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">star</i></div>
              <div class="icon-name">star</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">star_fill</i></div>
              <div class="icon-name">star_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">star_half</i></div>
              <div class="icon-name">star_half</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">stopwatch</i></div>
              <div class="icon-name">stopwatch</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">stopwatch_fill</i></div>
              <div class="icon-name">stopwatch_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">tabs</i></div>
              <div class="icon-name">tabs</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">tabs_fill</i></div>
              <div class="icon-name">tabs_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">tags</i></div>
              <div class="icon-name">tags</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">tags_fill</i></div>
              <div class="icon-name">tags_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">tape</i></div>
              <div class="icon-name">tape</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">tape_fill</i></div>
              <div class="icon-name">tape_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">ticket</i></div>
              <div class="icon-name">ticket</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">ticket_fill</i></div>
              <div class="icon-name">ticket_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">time</i></div>
              <div class="icon-name">time</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">time_fill</i></div>
              <div class="icon-name">time_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">timer</i></div>
              <div class="icon-name">timer</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">timer_fill</i></div>
              <div class="icon-name">timer_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">today</i></div>
              <div class="icon-name">today</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">today_fill</i></div>
              <div class="icon-name">today_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">trash</i></div>
              <div class="icon-name">trash</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">trash_fill</i></div>
              <div class="icon-name">trash_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">tune</i></div>
              <div class="icon-name">tune</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">tune_fill</i></div>
              <div class="icon-name">tune_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">undo</i></div>
              <div class="icon-name">undo</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">unlock</i></div>
              <div class="icon-name">unlock</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">unlock_fill</i></div>
              <div class="icon-name">unlock_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">up</i></div>
              <div class="icon-name">up</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">videocam</i></div>
              <div class="icon-name">videocam</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">videocam_fill</i></div>
              <div class="icon-name">videocam_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">videocam_round</i></div>
              <div class="icon-name">videocam_round</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">videocam_round_fill</i></div>
              <div class="icon-name">videocam_round_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">volume</i></div>
              <div class="icon-name">volume</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">volume_fill</i></div>
              <div class="icon-name">volume_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">volume_low</i></div>
              <div class="icon-name">volume_low</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">volume_low_fill</i></div>
              <div class="icon-name">volume_low_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">volume_mute</i></div>
              <div class="icon-name">volume_mute</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">volume_mute_fill</i></div>
              <div class="icon-name">volume_mute_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">world</i></div>
              <div class="icon-name">world</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">world_fill</i></div>
              <div class="icon-name">world_fill</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">zoom_in</i></div>
              <div class="icon-name">zoom_in</div>
            </div>
            <div class="ks-demo-icon col-33 tablet-15">
              <div class="icon"><i class="f7-icons">zoom_out</i></div>
              <div class="icon-name">zoom_out</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
