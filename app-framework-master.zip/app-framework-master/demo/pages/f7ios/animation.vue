<template>
  <div data-page="animation" class="page kitchen-sink-ios">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left sliding"><a class="back link" href="#"><i class="icon icon-back"></i><span>Back</span></a></div>
        <div class="center sliding">Animation</div>
      </div>
    </div>
    <div class="page-content">
      <div class="content-block">
        <div class="content-block-inner">
          <p>Framework7 comes with own simple and fast animation helper library to create custom JS animations:</p>
          <p><a href="#" class="button start">Animate</a></p>
          <div id="animate-me" style="width:100px; height:100px" class="bg-red"></div>
        </div>
      </div>
    </div>
  </div>
</template>
