<template>
  <div data-page="deep-navbar" class="page kitchen-sink-ios">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left sliding"><a class="back link" href="#">Navbars</a></div>
        <div class="center sliding">Deep Navbar</div>
      </div>
    </div>
    <div class="page-content">
      <div class="content-block">
        <div class="content-block-inner">
          <p>This demo demonstrates Framework7 exclusive behavior of dynamic sliding navigation bars. Just click the button below and look how navbar links will change. And don't forget to try swipe-back gesture on next pages:</p>
        </div>
        <p><a href="/f7ios/bars-deep-navbar-2/" class="button">Go to page 2</a></p>
      </div>
    </div>
  </div>
</template>
