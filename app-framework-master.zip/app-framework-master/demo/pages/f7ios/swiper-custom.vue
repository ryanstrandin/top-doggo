<template>
  <div data-page="swiper-custom" class="page no-toolbar kitchen-sink-ios">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left sliding"><a class="back link" href="#"><i class="icon icon-back"></i><span>Back</span></a></div>
        <div class="center sliding">Custom Controls</div>
      </div>
    </div>
    <div class="page-content">
      <div class="ks-slider-custom">
        <div data-pagination=".swiper-pagination" data-space-between="0" data-next-button=".swiper-button-next" data-prev-button=".swiper-button-prev" data-pagination-clickable="true" class="swiper-container swiper-init">
          <div class="swiper-pagination"></div>
          <div class="swiper-wrapper">
            <div style="background-image:url(http://lorempixel.com/1024/1024/nightlife/1)" class="swiper-slide"></div>
            <div style="background-image:url(http://lorempixel.com/1024/1024/nightlife/2)" class="swiper-slide"></div>
            <div style="background-image:url(http://lorempixel.com/1024/1024/nightlife/3)" class="swiper-slide"></div>
            <div style="background-image:url(http://lorempixel.com/1024/1024/nightlife/4)" class="swiper-slide"></div>
            <div style="background-image:url(http://lorempixel.com/1024/1024/nightlife/5)" class="swiper-slide"></div>
            <div style="background-image:url(http://lorempixel.com/1024/1024/nightlife/6)" class="swiper-slide"></div>
            <div style="background-image:url(http://lorempixel.com/1024/1024/nightlife/7)" class="swiper-slide"></div>
          </div>
          <div class="swiper-button-prev"></div>
          <div class="swiper-button-next"></div>
        </div>
      </div>
    </div>
  </div>
</template>
