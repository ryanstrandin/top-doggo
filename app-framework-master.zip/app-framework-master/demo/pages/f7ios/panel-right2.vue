<template>
  <div data-page="panel-right2" class="page kitchen-sink-ios">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left sliding"><a class="back link" href="#"><i class="icon icon-back"></i><span>Back</span></a></div>
        <div class="sliding center">Panel Page 2</div>
      </div>
    </div>
    <div class="page-content">
      <div class="content-block">
        <p>This is a panel page 2</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quo saepe aspernatur inventore dolorum voluptates consequatur tempore ipsum! Quia, incidunt, aliquam sit veritatis nisi aliquid porro similique ipsa mollitia eaque ex!</p>
      </div>
    </div>
  </div>
</template>
