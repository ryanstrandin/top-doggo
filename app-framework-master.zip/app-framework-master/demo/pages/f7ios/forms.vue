<template>
  <div data-page="forms" class="page kitchen-sink-ios">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left sliding"><a class="back link" href="#"><i class="icon icon-back"></i><span>Back</span></a></div>
        <div class="center sliding">Forms</div>
      </div>
    </div>
    <div class="page-content">
      <div class="content-block">
        <p>Framework7 provides very flexible forms layout, you can use it with/out icons, with/out labels, or mixed layouts.</p>
      </div>
      <div class="list-block">
        <ul>
          <li>
            <a href="/f7ios/forms-elements/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Form Elements</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/forms-checkboxes/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Checkboxes And Radios</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/forms-selects/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Smart Selects</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/forms-buttons/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Buttons</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/forms-storage/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Form Storage</div>
                </div>
              </div>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
