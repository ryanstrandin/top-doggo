<template>
  <div data-page="swiper-multiple" class="page kitchen-sink-ios">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left sliding"><a class="back link" href="#"><i class="icon icon-back"></i><span>Back</span></a></div>
        <div class="center sliding">Multiple Sliders</div>
      </div>
    </div>
    <div class="page-content">
      <div class="content-block-title">1 Slide Per View, 50px Between</div>
      <div data-pagination=".swiper-pagination-c1" data-space-between="50" class="swiper-container swiper-init ks-carousel-slider">
        <div class="swiper-pagination swiper-pagination-c1"></div>
        <div class="swiper-wrapper">
          <div class="swiper-slide">Slide 1</div>
          <div class="swiper-slide">Slide 2</div>
          <div class="swiper-slide">Slide 3</div>
          <div class="swiper-slide">Slide 4</div>
          <div class="swiper-slide">Slide 5</div>
          <div class="swiper-slide">Slide 6</div>
          <div class="swiper-slide">Slide 7</div>
          <div class="swiper-slide">Slide 8</div>
          <div class="swiper-slide">Slide 9</div>
          <div class="swiper-slide">Slide 10</div>
        </div>
      </div>
      <div class="content-block-title">2 Slides Per View, 20px Between</div>
      <div data-pagination=".swiper-pagination-c2" data-space-between="20" data-slidesperview="2" class="swiper-container swiper-init ks-carousel-slider">
        <div class="swiper-pagination swiper-pagination-c2"></div>
        <div class="swiper-wrapper">
          <div class="swiper-slide">Slide 1</div>
          <div class="swiper-slide">Slide 2</div>
          <div class="swiper-slide">Slide 3</div>
          <div class="swiper-slide">Slide 4</div>
          <div class="swiper-slide">Slide 5</div>
          <div class="swiper-slide">Slide 6</div>
          <div class="swiper-slide">Slide 7</div>
          <div class="swiper-slide">Slide 8</div>
          <div class="swiper-slide">Slide 9</div>
          <div class="swiper-slide">Slide 10</div>
        </div>
      </div>
      <div class="content-block-title">3 Slides Per View, 10px Between</div>
      <div data-pagination=".swiper-pagination-c3" data-space-between="10" data-slides-per-view="3" class="swiper-container swiper-init ks-carousel-slider">
        <div class="swiper-pagination swiper-pagination-c3"></div>
        <div class="swiper-wrapper">
          <div class="swiper-slide">Slide 1</div>
          <div class="swiper-slide">Slide 2</div>
          <div class="swiper-slide">Slide 3</div>
          <div class="swiper-slide">Slide 4</div>
          <div class="swiper-slide">Slide 5</div>
          <div class="swiper-slide">Slide 6</div>
          <div class="swiper-slide">Slide 7</div>
          <div class="swiper-slide">Slide 8</div>
          <div class="swiper-slide">Slide 9</div>
          <div class="swiper-slide">Slide 10</div>
        </div>
      </div>
      <div class="content-block-title">Auto Slides Per View + Centered</div>
      <div data-pagination=".swiper-pagination-c4" data-space-between="10" data-slides-per-view="auto" data-centered-slides="true" class="swiper-container swiper-init ks-carousel-slider ks-carousel-slider-auto">
        <div class="swiper-pagination swiper-pagination-c4"></div>
        <div class="swiper-wrapper">
          <div class="swiper-slide">Slide 1</div>
          <div class="swiper-slide">Slide 2</div>
          <div class="swiper-slide">Slide 3</div>
          <div class="swiper-slide">Slide 4</div>
          <div class="swiper-slide">Slide 5</div>
          <div class="swiper-slide">Slide 6</div>
          <div class="swiper-slide">Slide 7</div>
          <div class="swiper-slide">Slide 8</div>
          <div class="swiper-slide">Slide 9</div>
          <div class="swiper-slide">Slide 10</div>
        </div>
      </div>
      <div class="content-block-title">Vertical, 10px Between</div>
      <div data-pagination=".swiper-pagination-c5" data-space-between="10" data-direction="vertical" class="swiper-container swiper-init ks-carousel-slider">
        <div class="swiper-pagination swiper-pagination-c5"></div>
        <div class="swiper-wrapper">
          <div class="swiper-slide">Slide 1</div>
          <div class="swiper-slide">Slide 2</div>
          <div class="swiper-slide">Slide 3</div>
          <div class="swiper-slide">Slide 4</div>
          <div class="swiper-slide">Slide 5</div>
        </div>
      </div>
      <div class="content-block-title">Slow speed</div>
      <div data-speed="900" data-pagination=".swiper-pagination-c6" data-space-between="50" class="swiper-container swiper-init ks-carousel-slider">
        <div class="swiper-pagination swiper-pagination-c6"></div>
        <div class="swiper-wrapper">
          <div class="swiper-slide">Slide 1</div>
          <div class="swiper-slide">Slide 2</div>
          <div class="swiper-slide">Slide 3</div>
          <div class="swiper-slide">Slide 4</div>
          <div class="swiper-slide">Slide 5</div>
          <div class="swiper-slide">Slide 6</div>
          <div class="swiper-slide">Slide 7</div>
          <div class="swiper-slide">Slide 8</div>
          <div class="swiper-slide">Slide 9</div>
          <div class="swiper-slide">Slide 10</div>
        </div>
      </div>
    </div>
  </div>
</template>
