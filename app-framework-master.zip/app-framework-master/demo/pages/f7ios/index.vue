<template>
  <div data-page="index" class="page kitchen-sink-ios">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left sliding"><a href="#" class="back link"><i class="icon icon-back"></i><span>Back</span></a></div>
        <div class="center sliding">iOS</div>
      </div>
    </div>
    <div class="page-content">
  
      <div class="list-block">
        <ul>
          <li>
            <a href="/f7ios/accordion/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Accordion</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/autocomplete/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Autocomplete</div>
                  <div class="item-after"></div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/calendar/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Calendar / Datepicker</div>
                  <div class="item-after"></div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/cards/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Cards</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/chips/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Chips/Tags</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/contacts/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Contacts List</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/data-table/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Data Tables</div>
                  <div class="item-after"><span class="badge bg-green">NEW</span></div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/floating-button/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Floating Action Button</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/forms/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Forms</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/grid/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Grid</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/icons/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Icons</div>
                  <div class="item-after"><span class="badge bg-green">258</span></div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/infinite-scroll/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Infinite Scroll</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/lazy-load/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Lazy Load Images</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/list-view/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">List View</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/login-screen/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Login Screen</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/media-lists/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Media Lists</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/messages/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Messages</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/modals/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Modals</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/bars/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Navbars And Toolbars</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/notifications/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Notifications</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/photo-browser/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Photo Browser</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/picker/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Picker</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/popover/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Popover</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/preloader/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Preloader</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/progressbar/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Progress Bar</div>
                  <div class="item-after"></div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/pull-to-refresh/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Pull To Refresh</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/searchbar/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Search Bar </div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/panels/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Side Panels</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/sortable-list/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Sortable List</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/swipe-delete/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Swipe To Delete</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/swiper/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Swiper Slider</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/tabs/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Tabs</div>
                  <div class="item-after"></div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/timeline/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Timeline</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/virtual-list/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Virtual List</div>
                </div>
              </div>
            </a>
          </li>
        </ul>
      </div>
      <div class="list-block">
        <ul>
          <li>
            <a href="/f7ios/animation/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Animation</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/color-themes/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Color Themes</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="#" class="item-link ks-generate-page">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Dynamically Generated Content</div>
                </div>
              </div>
            </a>
          </li>
        </ul>
      </div>
      <div class="list-block">
        <ul>
          <li>
            <a href="/f7ios/transitions/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Transitions And Effects</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/core-features/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Core Features</div>
                </div>
              </div>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
