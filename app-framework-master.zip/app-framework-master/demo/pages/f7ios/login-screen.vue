<template>
  <div data-page="login-screen" class="page kitchen-sink-ios">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left sliding"><a class="back link" href="#"><i class="icon icon-back"></i><span>Back</span></a></div>
        <div class="center sliding">Login Screen</div>
      </div>
    </div>
    <div class="page-content">
      <div class="content-block">
        <p>Framework7 comes with ready to use Login Screen layout. It could be used inside of page or inside of popup (Embedded) or as a standalone overlay:</p>
      </div>
      <div class="content-block row">
        <div class="col-50"><a href="/f7ios/login-screen-embedded/" class="button">Embedded Into Page</a></div>
        <div class="col-50"><a href="#" class="button open-login-screen">As Overlay</a></div>
      </div>
    </div>
  </div>
</template>
