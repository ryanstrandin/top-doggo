<template>
  <div data-page="chips" class="page kitchen-sink-ios">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left"><a class="back link" href="#"><i class="icon icon-back"></i><span>Back</span></a></div>
        <div class="center">Chips/Tags</div>
      </div>
    </div>
    <div class="page-content">
      <div class="content-block">
        <p>Chips/Tags represent complex entities in small blocks, such as a contact. They can contain a photo, short title string, and brief information.</p>
      </div>
      <div class="content-block-title">Chips With Text</div>
      <div class="content-block">
        <div class="content-block-inner">
          <div class="chip">
            <div class="chip-label">Example Chip</div>
          </div>
          <div class="chip">
            <div class="chip-label">Another Chip</div>
          </div>
          <div class="chip">
            <div class="chip-label">One More Chip</div>
          </div>
          <div class="chip">
            <div class="chip-label">Fourth Chip</div>
          </div>
          <div class="chip">
            <div class="chip-label">Last One</div>
          </div>
        </div>
      </div>
      <div class="content-block-title">Icon Chips</div>
      <div class="content-block">
        <div class="content-block-inner">
          <div class="chip">
            <div class="chip-media"><i class="icon f7-icons">add_round</i></div>
            <div class="chip-label">Add Contact</div>
          </div>
          <div class="chip">
            <div class="chip-media"><i class="icon f7-icons">compass</i></div>
            <div class="chip-label">London</div>
          </div>
          <div class="chip">
            <div class="chip-media"><i class="icon f7-icons">person</i></div>
            <div class="chip-label">John Doe</div>
          </div>
        </div>
      </div>
      <div class="content-block-title">Contact Chips</div>
      <div class="content-block">
        <div class="content-block-inner">
          <div class="chip">
            <div class="chip-media"><img src="http://lorempixel.com/100/100/people/9/"></div>
            <div class="chip-label">Jane Doe</div>
          </div>
          <div class="chip">
            <div class="chip-media"><img src="http://lorempixel.com/100/100/people/3/"></div>
            <div class="chip-label">John Doe</div>
          </div>
          <div class="chip">
            <div class="chip-media"><img src="http://lorempixel.com/100/100/people/7/"></div>
            <div class="chip-label">Adam Smith</div>
          </div>
          <div class="chip">
            <div class="chip-media bg-pink">J</div>
            <div class="chip-label">Jennifer</div>
          </div>
          <div class="chip">
            <div class="chip-media bg-yellow color-black">C</div>
            <div class="chip-label">Chris</div>
          </div>
          <div class="chip">
            <div class="chip-media bg-red">K</div>
            <div class="chip-label">Kate</div>
          </div>
        </div>
      </div>
      <div class="content-block-title">Deletable Chips / Tags</div>
      <div class="content-block">
        <div class="content-block-inner">
          <div class="chip">
            <div class="chip-label">Example Chip</div><a href="#" class="chip-delete"></a>
          </div>
          <div class="chip">
            <div class="chip-media bg-orange color-black">C</div>
            <div class="chip-label">Chris</div><a href="#" class="chip-delete"></a>
          </div>
          <div class="chip">
            <div class="chip-media"><img src="http://lorempixel.com/100/100/people/9/"></div>
            <div class="chip-label">Jane Doe</div><a href="#" class="chip-delete"></a>
          </div>
          <div class="chip">
            <div class="chip-label">One More Chip</div><a href="#" class="chip-delete"></a>
          </div>
          <div class="chip">
            <div class="chip-media bg-pink">J</div>
            <div class="chip-label">Jennifer</div><a href="#" class="chip-delete"></a>
          </div>
          <div class="chip">
            <div class="chip-media"><img src="http://lorempixel.com/100/100/people/7/"></div>
            <div class="chip-label">Adam Smith</div><a href="#" class="chip-delete"></a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
