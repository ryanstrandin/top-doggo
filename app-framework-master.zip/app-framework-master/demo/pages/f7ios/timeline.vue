<template>
  <div data-page="timeline" class="page kitchen-sink-ios">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left sliding"><a class="back link" href="#"><i class="icon icon-back"></i><span>Back</span></a></div>
        <div class="center sliding">Timeline</div>
      </div>
    </div>
    <div class="page-content">
      <div class="list-block">
        <ul>
          <li>
            <a href="/f7ios/timeline-vertical/" class="item-content item-link">
              <div class="item-inner">
                <div class="item-title">Vertical Timeline</div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/timeline-horizontal/" class="item-content item-link">
              <div class="item-inner">
                <div class="item-title">Horizontal Timeline</div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7ios/timeline-horizontal-calendar/" class="item-content item-link">
              <div class="item-inner">
                <div class="item-title">Calendar Timeline</div>
              </div>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
