<template>
  <f7-page>
    <f7-navbar title="Right Panel" sliding></f7-navbar>
    <f7-block inner>
      <p>Right panel content goes here</p>
    </f7-block>
  </f7-page>
</template>
