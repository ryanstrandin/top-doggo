<template>
  <div data-page="login-screen-embedded" class="page kitchen-sink-material">
    <div class="page-content login-screen-content">
      <div class="login-screen-title">Framework7</div>
      <form>
        <div class="list-block inputs-list">
          <ul>
            <li class="item-content">
              <div class="item-inner">
                <div class="item-title label">Username</div>
                <div class="item-input">
                  <input type="text" name="username" placeholder="Your username">
                </div>
              </div>
            </li>
            <li class="item-content">
              <div class="item-inner">
                <div class="item-title label">Password</div>
                <div class="item-input">
                  <input type="password" name="password" placeholder="Your password">
                </div>
              </div>
            </li>
          </ul>
        </div>
        <div class="content-block"><a href="#" class="button button-big">Sign In</a></div>
        <div class="content-block">
          <div class="list-block-label">Some text about login information.<br>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</div>
        </div>
      </form>
    </div>
  </div>
</template>
