<template>
  <div data-page="navbars-toolbars" class="page kitchen-sink-material">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left"><a class="back link icon-only" href="#"><i class="icon icon-back"></i></a></div>
        <div class="center">Navbars And Toolbars</div>
      </div>
    </div>
    <div class="page-content">
      <div class="list-block">
        <ul>
          <li>
            <a href="/f7material/bars-tabbar/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Tab Bar</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/bars-tabbar-labels/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Tab Bar With Labels</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/bars-tabbar-scrollable/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Tab Bar Scrollable</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/bars-hide-on-scroll/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Hide Bars On Scroll</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/bars-sub-navbar/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Sub Navbar</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/bars-sub-navbar-title/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Sub Navbar Title</div>
                </div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/bars-toolbar-bottom/" class="item-link">
              <div class="item-content">
                <div class="item-media"><i class="icon icon-f7"></i></div>
                <div class="item-inner">
                  <div class="item-title">Bottom Toolbar</div>
                </div>
              </div>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
