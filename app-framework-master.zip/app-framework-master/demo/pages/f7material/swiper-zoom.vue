<template>
  <div data-page="swiper-zoom" class="page kitchen-sink-material">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left sliding"><a class="back link icon-only" href="#"><i class="icon icon-back"></i></a></div>
        <div class="center sliding">Zoom</div>
      </div>
    </div>
    <div class="page-content">
      <div data-pagination=".swiper-pagination" data-zoom="true" data-next-button=".swiper-button-next" data-prev-button=".swiper-button-prev" class="swiper-container swiper-init ks-demo-slider">
        <div class="swiper-wrapper">
          <div class="swiper-slide">
            <div class="swiper-zoom-container"><img src="http://lorempixel.com/800/800/nature/1"></div>
          </div>
          <div class="swiper-slide">
            <div class="swiper-zoom-container"><img src="http://lorempixel.com/800/800/nature/2"></div>
          </div>
          <div class="swiper-slide">
            <div class="swiper-zoom-container"><img src="http://lorempixel.com/800/800/nature/3"></div>
          </div>
          <div class="swiper-slide">
            <div class="swiper-zoom-container"><img src="http://lorempixel.com/800/800/nature/4"></div>
          </div>
          <div class="swiper-slide">
            <div class="swiper-zoom-container"><img src="http://lorempixel.com/800/800/nature/5"></div>
          </div>
          <div class="swiper-slide">
            <div class="swiper-zoom-container"><img src="http://lorempixel.com/800/800/nature/6"></div>
          </div>
          <div class="swiper-slide">
            <div class="swiper-zoom-container"><img src="http://lorempixel.com/800/800/nature/7"></div>
          </div>
          <div class="swiper-slide">
            <div class="swiper-zoom-container"><img src="http://lorempixel.com/800/800/nature/8"></div>
          </div>
          <div class="swiper-slide">
            <div class="swiper-zoom-container"><img src="http://lorempixel.com/800/800/nature/9"></div>
          </div>
        </div>
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
        <div class="swiper-pagination"></div>
      </div>
    </div>
  </div>
</template>
