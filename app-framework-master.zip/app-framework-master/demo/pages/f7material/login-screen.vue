<template>
  <div data-page="login-screen" class="page kitchen-sink-material">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left"><a class="back link icon-only" href="#"><i class="icon icon-back"></i></a></div>
        <div class="center">Login Screen</div>
      </div>
    </div>
    <div class="page-content">
      <div class="content-block">
        <p>Framework7 comes with ready to use Login Screen layout. It could be used inside of page or inside of popup (Embedded) or as a standalone overlay:</p>
      </div>
      <div class="content-block row">
        <div class="col-50"><a href="/f7material/login-screen-embedded/" class="button button-raised">Embedded Into Page</a></div>
        <div class="col-50"><a href="#" class="button button-raised open-login-screen">As Overlay</a></div>
      </div>
    </div>
  </div>
</template>
