<template>
  <div data-page="notifications" class="page kitchen-sink-material">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left"><a class="back link icon-only" href="#"><i class="icon icon-back"></i></a></div>
        <div class="center">Notifications</div>
      </div>
    </div>
    <div class="page-content">
      <div class="content-block">
        <p>Framework7 comes with simple Notifications component that allows you to show some useful messages to user and request basic actions. Such notification are also called Snackbars &amp; Toasts in Android </p>
        <p><a href="#" class="button button-raised ks-notification-1">Single-line message</a></p>
        <p><a href="#" class="button button-raised ks-notification-2">Multi-line message</a></p>
        <p><a href="#" class="button button-raised ks-notification-3">With custom button</a></p>
        <p><a href="#" class="button button-raised ks-notification-4">With callback on close</a></p>
      </div>
    </div>
  </div>
</template>
