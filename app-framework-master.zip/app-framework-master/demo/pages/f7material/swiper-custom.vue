<template>
  <div data-page="swiper-custom" class="page kitchen-sink-material">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left"><a class="back link icon-only" href="#"><i class="icon icon-back"></i></a></div>
        <div class="center">Custom Controls</div>
      </div>
    </div>
    <div class="page-content">
      <div class="ks-slider-custom">
        <div data-pagination=".swiper-pagination" data-spacebetween="0" data-nextbutton=".swiper-button-next" data-prevbutton=".swiper-button-prev" data-paginationclickable="true" class="swiper-container swiper-init">
          <div class="swiper-pagination"></div>
          <div class="swiper-wrapper">
            <div style="background-image:url(http://lorempixel.com/1024/1024/nightlife/1)" class="swiper-slide"></div>
            <div style="background-image:url(http://lorempixel.com/1024/1024/nightlife/2)" class="swiper-slide"></div>
            <div style="background-image:url(http://lorempixel.com/1024/1024/nightlife/3)" class="swiper-slide"></div>
            <div style="background-image:url(http://lorempixel.com/1024/1024/nightlife/4)" class="swiper-slide"></div>
            <div style="background-image:url(http://lorempixel.com/1024/1024/nightlife/5)" class="swiper-slide"></div>
            <div style="background-image:url(http://lorempixel.com/1024/1024/nightlife/6)" class="swiper-slide"></div>
            <div style="background-image:url(http://lorempixel.com/1024/1024/nightlife/7)" class="swiper-slide"></div>
          </div>
          <div class="swiper-button-prev"></div>
          <div class="swiper-button-next"></div>
        </div>
      </div>
    </div>
  </div>
</template>
