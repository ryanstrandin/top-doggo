<template>
  <div data-page="no-navbar-toolbar" class="page no-navbar no-toolbar kitchen-sink-material">
    <div class="page-content">
      <div class="content-block">
        <div class="content-block-inner">
          <p>On this page Navbar and Toolbar were hidden dynamically. Just add "no-toolbar no-navbar" class to this page to make it work.</p>
        </div>
        <p><a href="#" class="back button">Go Back </a></p>
      </div>
    </div>
  </div>
</template>
