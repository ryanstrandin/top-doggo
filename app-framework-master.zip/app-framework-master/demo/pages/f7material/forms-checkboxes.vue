<template>
  <div data-page="forms-checkboxes" class="page kitchen-sink-material">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left"><a class="back link icon-only" href="#"><i class="icon icon-back"></i></a></div>
        <div class="center">Checkboxes And Radios</div>
      </div>
    </div>
    <div class="page-content">
      <div class="content-block-title">Checkbox group</div>
      <div class="list-block">
        <ul>
          <li>
            <label class="label-checkbox item-content">
              <input type="checkbox" name="ks-checkbox" value="Books" checked="checked">
              <div class="item-media"><i class="icon icon-form-checkbox"></i></div>
              <div class="item-inner">
                <div class="item-title">Books</div>
              </div>
            </label>
          </li>
          <li>
            <label class="label-checkbox item-content">
              <input type="checkbox" name="ks-checkbox" value="Movies">
              <div class="item-media"><i class="icon icon-form-checkbox"></i></div>
              <div class="item-inner">
                <div class="item-title">Movies</div>
              </div>
            </label>
          </li>
          <li>
            <label class="label-checkbox item-content">
              <input type="checkbox" name="ks-checkbox" value="Food">
              <div class="item-media"><i class="icon icon-form-checkbox"></i></div>
              <div class="item-inner">
                <div class="item-title">Food</div>
              </div>
            </label>
          </li>
          <li>
            <label class="label-checkbox item-content">
              <input type="checkbox" name="ks-checkbox" value="Drinks">
              <div class="item-media"><i class="icon icon-form-checkbox"></i></div>
              <div class="item-inner">
                <div class="item-title">Drinks</div>
              </div>
            </label>
          </li>
        </ul>
      </div>
      <div class="content-block-title">Radio buttons group</div>
      <div class="list-block">
        <ul>
          <li>
            <label class="label-radio item-content">
              <input type="radio" name="ks-radio" value="Books" checked="checked">
              <div class="item-media"><i class="icon icon-form-radio"></i></div>
              <div class="item-inner">
                <div class="item-title">Books</div>
              </div>
            </label>
          </li>
          <li>
            <label class="label-radio item-content">
              <input type="radio" name="ks-radio" value="Movies">
              <div class="item-media"><i class="icon icon-form-radio"></i></div>
              <div class="item-inner">
                <div class="item-title">Movies</div>
              </div>
            </label>
          </li>
          <li>
            <label class="label-radio item-content">
              <input type="radio" name="ks-radio" value="Food">
              <div class="item-media"><i class="icon icon-form-radio"></i></div>
              <div class="item-inner">
                <div class="item-title">Food</div>
              </div>
            </label>
          </li>
          <li>
            <label class="label-radio item-content">
              <input type="radio" name="ks-radio" value="Drinks">
              <div class="item-media"><i class="icon icon-form-radio"></i></div>
              <div class="item-inner">
                <div class="item-title">Drinks</div>
              </div>
            </label>
          </li>
        </ul>
      </div>
      <div class="content-block-title">With Media Lists</div>
      <div class="list-block media-list">
        <ul>
          <li>
            <label class="label-checkbox item-content">
              <input type="checkbox" name="ks-media-checkbox" value="1">
              <div class="item-media"><i class="icon icon-form-checkbox"></i></div>
              <div class="item-inner">
                <div class="item-title-row">
                  <div class="item-title">Facebook</div>
                  <div class="item-after">17:14</div>
                </div>
                <div class="item-subtitle">New messages from John Doe</div>
                <div class="item-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sagittis tellus ut turpis condimentum, ut dignissim lacus tincidunt. Cras dolor metus, ultrices condimentum sodales sit amet, pharetra sodales eros. Phasellus vel felis tellus. Mauris rutrum ligula nec dapibus feugiat. In vel dui laoreet, commodo augue id, pulvinar lacus.</div>
              </div>
            </label>
          </li>
          <li>
            <label class="label-checkbox item-content">
              <input type="checkbox" name="ks-media-checkbox" value="2">
              <div class="item-media"><i class="icon icon-form-checkbox"></i></div>
              <div class="item-inner">
                <div class="item-title-row">
                  <div class="item-title">John Doe (via Twitter)</div>
                  <div class="item-after">17:11</div>
                </div>
                <div class="item-subtitle">John Doe (@_johndoe) mentioned you on Twitter!</div>
                <div class="item-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sagittis tellus ut turpis condimentum, ut dignissim lacus tincidunt. Cras dolor metus, ultrices condimentum sodales sit amet, pharetra sodales eros. Phasellus vel felis tellus. Mauris rutrum ligula nec dapibus feugiat. In vel dui laoreet, commodo augue id, pulvinar lacus.</div>
              </div>
            </label>
          </li>
          <li>
            <label class="label-checkbox item-content">
              <input type="checkbox" name="ks-media-checkbox" value="3">
              <div class="item-media"><i class="icon icon-form-checkbox"></i></div>
              <div class="item-inner">
                <div class="item-title-row">
                  <div class="item-title">Facebook</div>
                  <div class="item-after">16:48</div>
                </div>
                <div class="item-subtitle">New messages from John Doe</div>
                <div class="item-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sagittis tellus ut turpis condimentum, ut dignissim lacus tincidunt. Cras dolor metus, ultrices condimentum sodales sit amet, pharetra sodales eros. Phasellus vel felis tellus. Mauris rutrum ligula nec dapibus feugiat. In vel dui laoreet, commodo augue id, pulvinar lacus.</div>
              </div>
            </label>
          </li>
          <li>
            <label class="label-checkbox item-content">
              <input type="checkbox" name="ks-media-checkbox" value="4">
              <div class="item-media"><i class="icon icon-form-checkbox"></i></div>
              <div class="item-inner">
                <div class="item-title-row">
                  <div class="item-title">John Doe (via Twitter)</div>
                  <div class="item-after">15:32</div>
                </div>
                <div class="item-subtitle">John Doe (@_johndoe) mentioned you on Twitter!</div>
                <div class="item-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sagittis tellus ut turpis condimentum, ut dignissim lacus tincidunt. Cras dolor metus, ultrices condimentum sodales sit amet, pharetra sodales eros. Phasellus vel felis tellus. Mauris rutrum ligula nec dapibus feugiat. In vel dui laoreet, commodo augue id, pulvinar lacus.</div>
              </div>
            </label>
          </li>
        </ul>
      </div>
      <div class="content-block-title">What is your favourite song?</div>
      <div class="list-block media-list">
        <ul>
          <li>
            <label class="label-radio item-content">
              <input type="radio" name="ks-media-radio" value="1" checked="checked">
              <div class="item-media"><img src="http://lorempixel.com/160/160/fashion/1" width="80"></div>
              <div class="item-inner">
                <div class="item-title-row">
                  <div class="item-title">Yellow Submarine</div>
                  <div class="item-after">$15</div>
                </div>
                <div class="item-subtitle">Beatles</div>
                <div class="item-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sagittis tellus ut turpis condimentum, ut dignissim lacus tincidunt. Cras dolor metus, ultrices condimentum sodales sit amet, pharetra sodales eros. Phasellus vel felis tellus. Mauris rutrum ligula nec dapibus feugiat. In vel dui laoreet, commodo augue id, pulvinar lacus.</div>
              </div>
              <div class="item-after"><i class="icon-form-radio"></i></div>
            </label>
          </li>
          <li>
            <label class="label-radio item-content">
              <input type="radio" name="ks-media-radio" value="2">
              <div class="item-media"><img src="http://lorempixel.com/160/160/fashion/2" width="80"></div>
              <div class="item-inner">
                <div class="item-title-row">
                  <div class="item-title">Don't Stop Me Now</div>
                  <div class="item-after">$22</div>
                </div>
                <div class="item-subtitle">Queen</div>
                <div class="item-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sagittis tellus ut turpis condimentum, ut dignissim lacus tincidunt. Cras dolor metus, ultrices condimentum sodales sit amet, pharetra sodales eros. Phasellus vel felis tellus. Mauris rutrum ligula nec dapibus feugiat. In vel dui laoreet, commodo augue id, pulvinar lacus.</div>
              </div>
              <div class="item-after"><i class="icon-form-radio"></i></div>
            </label>
          </li>
          <li>
            <label class="label-radio item-content">
              <input type="radio" name="ks-media-radio" value="3">
              <div class="item-media"><img src="http://lorempixel.com/160/160/fashion/3" width="80"></div>
              <div class="item-inner">
                <div class="item-title-row">
                  <div class="item-title">Billie Jean</div>
                  <div class="item-after">$16</div>
                </div>
                <div class="item-subtitle">Michael Jackson</div>
                <div class="item-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sagittis tellus ut turpis condimentum, ut dignissim lacus tincidunt. Cras dolor metus, ultrices condimentum sodales sit amet, pharetra sodales eros. Phasellus vel felis tellus. Mauris rutrum ligula nec dapibus feugiat. In vel dui laoreet, commodo augue id, pulvinar lacus.</div>
              </div>
              <div class="item-after"><i class="icon-form-radio"></i></div>
            </label>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
