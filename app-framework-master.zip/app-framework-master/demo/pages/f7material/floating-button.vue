<template>
  <div data-page="floating-button" class="page kitchen-sink-material">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left"><a class="back link icon-only" href="#"><i class="icon icon-back"></i></a></div>
        <div class="center">Floating Action Button</div>
      </div>
    </div>
    <div class="page-content">
      <div class="list-block">
        <ul>
          <li>
            <a href="/f7material/floating-button-static/" class="item-content item-link">
              <div class="item-media"><i class="icon icon-f7"></i></div>
              <div class="item-inner">
                <div class="item-title">Static Floating Action Button</div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/floating-button-dial/" class="item-content item-link">
              <div class="item-media"><i class="icon icon-f7"></i></div>
              <div class="item-inner">
                <div class="item-title">Speed Dial</div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/floating-button-popover/" class="item-content item-link">
              <div class="item-media"><i class="icon icon-f7"></i></div>
              <div class="item-inner">
                <div class="item-title">Morph To Popover</div>
              </div>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
