<template>
  <div data-page="pickers" class="page kitchen-sink-material">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left"><a class="back link icon-only" href="#"><i class="icon icon-back"></i></a></div>
        <div class="center">Picker</div>
      </div>
    </div>
    <div class="page-content">
      <div class="content-block">
        <p>Picker is a powerful component that allows you to create custom overlay pickers which looks like iOS picker.</p>
        <p>Picker could be used as inline component or as overlay. Overlay Picker will be automatically converted to Popover on tablets.</p>
      </div>
      <div class="content-block-title">Picker with single value</div>
      <div class="list-block">
        <ul>
          <li>
            <div class="item-content">
              <div class="item-inner">
                <div class="item-input">
                  <input type="text" placeholder="Your iOS device" readonly="readonly" id="ks-picker-device">
                </div>
              </div>
            </div>
          </li>
        </ul>
      </div>
      <div class="content-block-title">2 values and 3d-rotate effect</div>
      <div class="list-block">
        <ul>
          <li>
            <div class="item-content">
              <div class="item-inner">
                <div class="item-input">
                  <input type="text" placeholder="Describe yourself" readonly="readonly" id="ks-picker-describe">
                </div>
              </div>
            </div>
          </li>
        </ul>
      </div>
      <div class="content-block-title">Dependent values</div>
      <div class="list-block">
        <ul>
          <li>
            <div class="item-content">
              <div class="item-inner">
                <div class="item-input">
                  <input type="text" placeholder="Your car" readonly="readonly" id="ks-picker-dependent">
                </div>
              </div>
            </div>
          </li>
        </ul>
      </div>
      <div class="content-block-title">Custom toolbar</div>
      <div class="list-block">
        <ul>
          <li>
            <div class="item-content">
              <div class="item-inner">
                <div class="item-input">
                  <input type="text" placeholder="Describe yourself" readonly="readonly" id="ks-picker-custom-toolbar">
                </div>
              </div>
            </div>
          </li>
        </ul>
      </div>
      <div class="content-block-title">Inline Picker / Date-time</div>
      <div style="margin:0" class="list-block">
        <ul>
          <li>
            <div class="item-content">
              <div class="item-inner">
                <div class="item-input">
                  <input type="text" placeholder="Date Time" readonly="readonly" id="ks-picker-date">
                </div>
              </div>
            </div>
          </li>
        </ul>
      </div>
      <div id="ks-picker-date-container"></div>
    </div>
  </div>
</template>
