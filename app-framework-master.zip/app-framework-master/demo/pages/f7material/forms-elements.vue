<template>
  <div data-page="form-elements" class="page kitchen-sink-material">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left"><a class="back link icon-only" href="#"><i class="icon icon-back"></i></a></div>
        <div class="center">Form Elements</div>
      </div>
    </div>
    <div class="page-content">
      <div class="content-block-title">Full Layout</div>
      <form class="list-block inputs-list">
        <ul>
          <li>
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-title label">Name</div>
                <div class="item-input">
                  <input type="text" placeholder="Your name">
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-title label">E-mail</div>
                <div class="item-input">
                  <input type="email" placeholder="E-mail">
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-title label">URL</div>
                <div class="item-input">
                  <input type="url" placeholder="URL">
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-title label">Password</div>
                <div class="item-input">
                  <input type="password" placeholder="Password">
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-title label">Phone</div>
                <div class="item-input">
                  <input type="tel" placeholder="Phone">
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-title label">Gender</div>
                <div class="item-input">
                  <select>
                    <option>Male</option>
                    <option>Female</option>
                  </select>
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-title label">Birth date</div>
                <div class="item-input">
                  <input type="date" placeholder="Birth day" value="2014-04-30">
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-title label">Date time</div>
                <div class="item-input">
                  <input type="datetime-local" placeholder="Birth day">
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-title label">Switch</div>
                <div class="item-input">
                  <label class="label-switch">
                    <input type="checkbox">
                    <div class="checkbox"></div>
                  </label>
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-title label">Slider</div>
                <div class="item-input">
                  <div class="range-slider">
                    <input type="range" min="0" max="100" value="50" step="0.1">
                  </div>
                </div>
              </div>
            </div>
          </li>
          <li class="align-top">
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-title label">Resizeable Textarea</div>
                <div class="item-input">
                  <textarea class="resizable"></textarea>
                </div>
              </div>
            </div>
          </li>
        </ul>
      </form>
      <div class="content-block-title">With Floating Labels</div>
      <form class="list-block inputs-list">
        <ul>
          <li>
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-title floating-label">Your name</div>
                <div class="item-input">
                  <input type="text" placeholder="">
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-title floating-label">E-mail</div>
                <div class="item-input">
                  <input type="email" placeholder="">
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-title floating-label">URL</div>
                <div class="item-input">
                  <input type="url" placeholder="">
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-title floating-label">Password</div>
                <div class="item-input">
                  <input type="password" placeholder="">
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-title floating-label">Phone</div>
                <div class="item-input">
                  <input type="tel" placeholder="">
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-title floating-label">Gender</div>
                <div class="item-input">
                  <select>
                    <option> </option>
                    <option>Male</option>
                    <option>Female</option>
                  </select>
                </div>
              </div>
            </div>
          </li>
          <li class="align-top">
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-title floating-label">Resizeable Textarea</div>
                <div class="item-input">
                  <textarea class="resizable"></textarea>
                </div>
              </div>
            </div>
          </li>
        </ul>
      </form>
      <div class="content-block-title">Icons and inputs</div>
      <form class="list-block inputs-list">
        <ul>
          <li>
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-input">
                  <input type="text" placeholder="Your name">
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-input">
                  <input type="email" placeholder="E-mail">
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-input">
                  <select>
                    <option>Male</option>
                    <option>Female</option>
                  </select>
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-input">
                  <input type="date" placeholder="Birth day" value="2014-04-30">
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-media"><i class="icon material-icons"></i></div>
              <div class="item-inner">
                <div class="item-input">
                  <label class="label-switch">
                    <input type="checkbox">
                    <div class="checkbox"></div>
                  </label>
                </div>
              </div>
            </div>
          </li>
        </ul>
      </form>
      <div class="content-block-title">Labels and inputs</div>
      <form class="list-block inputs-list">
        <ul>
          <li>
            <div class="item-content">
              <div class="item-inner">
                <div class="item-title label">Name</div>
                <div class="item-input">
                  <input type="text" placeholder="Your name">
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-inner">
                <div class="item-title label">E-mail</div>
                <div class="item-input">
                  <input type="email" placeholder="E-mail">
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-inner">
                <div class="item-title label">Gender</div>
                <div class="item-input">
                  <select>
                    <option>Male</option>
                    <option>Female</option>
                  </select>
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-inner">
                <div class="item-title label">Birth date</div>
                <div class="item-input">
                  <input type="date" placeholder="Birth day" value="2014-04-30">
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-inner">
                <div class="item-title label">Switch</div>
                <div class="item-input">
                  <label class="label-switch">
                    <input type="checkbox">
                    <div class="checkbox"></div>
                  </label>
                </div>
              </div>
            </div>
          </li>
        </ul>
      </form>
      <div class="content-block-title">Just inputs</div>
      <form class="list-block inputs-list">
        <ul>
          <li>
            <div class="item-content">
              <div class="item-inner">
                <div class="item-input">
                  <input type="text" placeholder="Your name">
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-inner">
                <div class="item-input">
                  <input type="email" placeholder="E-mail">
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-inner">
                <div class="item-input">
                  <select>
                    <option>Male</option>
                    <option>Female</option>
                  </select>
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-inner">
                <div class="item-input">
                  <input type="date" placeholder="Birth day" value="2014-04-30">
                </div>
              </div>
            </div>
          </li>
        </ul>
      </form>
      <div class="content-block-title">Inset, just inputs</div>
      <form class="list-block inset inputs-list">
        <ul>
          <ul></ul>
          <li>
            <div class="item-content">
              <div class="item-inner">
                <div class="item-input">
                  <input type="text" placeholder="Your name">
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-inner">
                <div class="item-input">
                  <input type="email" placeholder="E-mail">
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-inner">
                <div class="item-input">
                  <select>
                    <option>Male</option>
                    <option>Female</option>
                  </select>
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="item-content">
              <div class="item-inner">
                <div class="item-input">
                  <input type="date" placeholder="Birth day" value="2014-04-30">
                </div>
              </div>
            </div>
          </li>
        </ul>
      </form>
    </div>
  </div>
</template>
