<template>
  <div data-page="messages" class="page kitchen-sink-material">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left"><a class="back link icon-only" href="#"><i class="icon icon-back"></i></a></div>
        <div class="center">Messages</div>
      </div>
    </div>
    <div class="toolbar messagebar">
      <div class="toolbar-inner"><a href="#" class="link icon-only"><i class="icon icon-camera"></i></a>
        <textarea placeholder="Message"></textarea><a href="#" class="link send-message">Send</a>
      </div>
    </div>
    <div class="page-content messages-content">
      <div class="messages messages-auto-layout">
        <div class="message message-sent message-with-avatar">
          <div class="message-text">Hi, Kate
            <div class="message-date">Feb 9, 12:58</div>
          </div>
          <div style="background-image:url(http://lorempixel.com/200/200/people/6)" class="message-avatar"></div>
        </div>
        <div class="message message-sent message-with-avatar">
          <div class="message-text">How are you?
            <div class="message-date">Feb 9, 12:59</div>
          </div>
          <div style="background-image:url(http://lorempixel.com/200/200/people/6)" class="message-avatar"></div>
        </div>
        <div class="message message-received message-with-avatar">
          <div class="message-name">Kate Johnson</div>
          <div class="message-text">Hi, i am good
            <div class="message-date">Feb 9, 13:11</div>
          </div>
          <div style="background-image:url(http://lorempixel.com/200/200/people/9)" class="message-avatar"></div>
        </div>
        <div class="message message-received message-with-avatar">
          <div class="message-name">Blue Ninja</div>
          <div class="message-text">Hi there, I am also fine, thanks! And how are you?
            <div class="message-date">Feb 9, 13:23</div>
          </div>
          <div style="background-image:url(http://lorempixel.com/200/200/people/7)" class="message-avatar"></div>
        </div>
        <div class="message message-sent message-with-avatar">
          <div class="message-text">Hey, Blue Ninja! Glad to see you ;)
            <div class="message-date">Feb 9, 13:28</div>
          </div>
          <div style="background-image:url(http://lorempixel.com/200/200/people/6)" class="message-avatar"></div>
        </div>
        <div class="message message-sent message-with-avatar">
          <div class="message-text">What do you think about my new logo?
            <div class="message-date">Feb 9, 13:30</div>
          </div>
          <div style="background-image:url(http://lorempixel.com/200/200/people/6)" class="message-avatar"></div>
        </div>
        <div class="message message-sent message-with-avatar">
          <div class="message-text">Hey? Any thoughts about my new logo?
            <div class="message-date">Feb 11, 9:21</div>
          </div>
          <div style="background-image:url(http://lorempixel.com/200/200/people/6)" class="message-avatar"></div>
        </div>
        <div class="message message-sent message-with-avatar">
          <div class="message-text">Alo...
            <div class="message-date">Feb 12, 19:55</div>
          </div>
          <div style="background-image:url(http://lorempixel.com/200/200/people/6)" class="message-avatar"></div>
        </div>
        <div class="message message-sent message-with-avatar">
          <div class="message-text">Are you there?
            <div class="message-date">Feb 12, 20:07</div>
          </div>
          <div style="background-image:url(http://lorempixel.com/200/200/people/6)" class="message-avatar"></div>
        </div>
        <div class="message message-received message-with-avatar">
          <div class="message-name">Blue Ninja</div>
          <div class="message-text">Hi, i am here
            <div class="message-date">Feb 13, 11:24</div>
          </div>
          <div style="background-image:url(http://lorempixel.com/200/200/people/7)" class="message-avatar"></div>
        </div>
        <div class="message message-received message-with-avatar">
          <div class="message-name">Blue Ninja</div>
          <div class="message-text">Your logo is great
            <div class="message-date">Feb 13, 11:30</div>
          </div>
          <div style="background-image:url(http://lorempixel.com/200/200/people/7)" class="message-avatar"></div>
        </div>
        <div class="message message-received message-with-avatar">
          <div class="message-name">Kate Johnson</div>
          <div class="message-text">Leave me alone!
            <div class="message-date">Feb 13, 15:57</div>
          </div>
          <div style="background-image:url(http://lorempixel.com/200/200/people/9)" class="message-avatar"></div>
        </div>
        <div class="message message-sent message-with-avatar">
          <div class="message-text">:(
            <div class="message-date">Feb 13, 16:02</div>
          </div>
          <div style="background-image:url(http://lorempixel.com/200/200/people/6)" class="message-avatar"></div>
        </div>
        <div class="message message-sent message-with-avatar">
          <div class="message-text">Hey, look, cutest kitten ever!
            <div class="message-date">Feb 13, 16:10</div>
          </div>
          <div style="background-image:url(http://lorempixel.com/200/200/people/6)" class="message-avatar"></div>
        </div>
        <div class="message message-sent message-pic message-with-avatar">
          <div class="message-text"><img src="http://lorempixel.com/300/400/cats/4/">
            <div class="message-date">Feb 13, 16:10</div>
          </div>
          <div style="background-image:url(http://lorempixel.com/200/200/people/6)" class="message-avatar"></div>
        </div>
        <div class="message message-received message-with-avatar">
          <div class="message-name">Blue Ninja</div>
          <div class="message-text">Yep
            <div class="message-date">Feb 14, 8:45</div>
          </div>
          <div style="background-image:url(http://lorempixel.com/200/200/people/7)" class="message-avatar"></div>
        </div>
        <div class="message message-sent message-with-avatar">
          <div class="message-text">Cool
            <div class="message-date">Feb 14, 12:31</div>
          </div>
          <div style="background-image:url(http://lorempixel.com/200/200/people/6)" class="message-avatar"></div>
        </div>
      </div>
    </div>
  </div>
</template>
