<template>
  <div data-page="icons" class="page kitchen-sink-material">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left sliding"><a class="back link icon-only" href="#"><i class="icon icon-back"></i></a></div>
        <div class="center sliding">Icons</div>
      </div>
    </div>
    <div class="page-content">
      <div class="content-block">
        <p>Framework7 comes with the premium and free <a href="https://github.com/nolimits4web/Framework7-Icons" class="external" target="_blank">Framework7 Icons</a> iOS-icons font developed specially to be used with iOS theme of Framework7, but for Material
          theme we recommend to use great-designed <a href="https://material.io/icons/" class="external" target="_blank">Material Icons</a> font. Both of these fonts use a typographic feature called <a href="http://alistapart.com/article/the-era-of-symbol-fonts"
            class="external" target="_blank">ligatures</a>. It’s easy to incorporate icons into your app. Here’s a small example:</p>
        <p><code>&lt;i class="material-icons"&gt;home&lt;/i&gt;</code> - <i class="material-icons"></i></p>
        <p><a href="http://alistapart.com/article/the-era-of-symbol-fonts" class="external" target="_blank">Ligatures</a> allow rendering of an icon glyph simply by using its textual name. The replacement is done automatically by the web browser and provides
          more readable code than the equivalent numeric character reference.</p>
        <p>With ligatures it is also possible to combine icons like:</p>
        <p><code>&lt;i class="material-icons"&gt;person&lt;sup&gt;add&lt;/sup&gt;&lt;/i&gt;</code> - <i class="material-icons">person<sup>add</sup></i></p>
      </div>
      <div class="content-block-title">Material Icons Set (932)</div>
      <div class="content-block">
        <div class="row">
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">3d_rotation</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">ac_unit</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">access_alarm</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">access_alarms</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">access_time</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">accessibility</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">accessible</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">account_balance</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">account_balance_wallet</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">account_box</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">account_circle</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">adb</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">add</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">add_a_photo</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">add_alarm</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">add_alert</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">add_box</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">add_circle</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">add_circle_outline</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">add_location</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">add_shopping_cart</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">add_to_photos</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">add_to_queue</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">adjust</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">airline_seat_flat</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">airline_seat_flat_angled</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">airline_seat_individual_suite</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">airline_seat_legroom_extra</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">airline_seat_legroom_normal</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">airline_seat_legroom_reduced</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">airline_seat_recline_extra</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">airline_seat_recline_normal</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">airplanemode_active</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">airplanemode_inactive</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">airplay</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">airport_shuttle</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">alarm</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">alarm_add</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">alarm_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">alarm_on</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">album</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">all_inclusive</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">all_out</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">android</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">announcement</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">apps</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">archive</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">arrow_back</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">arrow_downward</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">arrow_drop_down</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">arrow_drop_down_circle</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">arrow_drop_up</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">arrow_forward</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">arrow_upward</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">art_track</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">aspect_ratio</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">assessment</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">assignment</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">assignment_ind</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">assignment_late</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">assignment_return</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">assignment_returned</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">assignment_turned_in</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">assistant</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">assistant_photo</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">attach_file</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">attach_money</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">attachment</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">audiotrack</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">autorenew</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">av_timer</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">backspace</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">backup</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">battery_alert</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">battery_charging_full</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">battery_full</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">battery_std</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">battery_unknown</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">beach_access</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">beenhere</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">block</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">bluetooth</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">bluetooth_audio</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">bluetooth_connected</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">bluetooth_disabled</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">bluetooth_searching</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">blur_circular</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">blur_linear</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">blur_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">blur_on</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">book</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">bookmark</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">bookmark_border</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">border_all</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">border_bottom</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">border_clear</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">border_color</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">border_horizontal</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">border_inner</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">border_left</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">border_outer</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">border_right</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">border_style</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">border_top</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">border_vertical</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">branding_watermark</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">brightness_1</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">brightness_2</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">brightness_3</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">brightness_4</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">brightness_5</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">brightness_6</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">brightness_7</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">brightness_auto</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">brightness_high</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">brightness_low</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">brightness_medium</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">broken_image</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">brush</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">bubble_chart</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">bug_report</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">build</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">burst_mode</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">business</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">business_center</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">cached</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">cake</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">call</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">call_end</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">call_made</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">call_merge</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">call_missed</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">call_missed_outgoing</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">call_received</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">call_split</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">call_to_action</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">camera</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">camera_alt</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">camera_enhance</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">camera_front</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">camera_rear</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">camera_roll</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">cancel</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">card_giftcard</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">card_membership</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">card_travel</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">casino</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">cast</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">cast_connected</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">center_focus_strong</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">center_focus_weak</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">change_history</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">chat</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">chat_bubble</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">chat_bubble_outline</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">check</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">check_box</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">check_box_outline_blank</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">check_circle</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">chevron_left</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">chevron_right</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">child_care</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">child_friendly</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">chrome_reader_mode</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">class</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">clear</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">clear_all</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">close</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">closed_caption</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">cloud</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">cloud_circle</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">cloud_done</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">cloud_download</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">cloud_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">cloud_queue</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">cloud_upload</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">code</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">collections</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">collections_bookmark</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">color_lens</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">colorize</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">comment</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">compare</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">compare_arrows</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">computer</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">confirmation_number</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">contact_mail</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">contact_phone</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">contacts</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">content_copy</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">content_cut</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">content_paste</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">control_point</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">control_point_duplicate</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">copyright</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">create</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">create_new_folder</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">credit_card</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">crop</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">crop_16_9</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">crop_3_2</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">crop_5_4</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">crop_7_5</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">crop_din</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">crop_free</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">crop_landscape</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">crop_original</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">crop_portrait</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">crop_rotate</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">crop_square</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">dashboard</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">data_usage</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">date_range</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">dehaze</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">delete</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">delete_forever</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">delete_sweep</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">description</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">desktop_mac</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">desktop_windows</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">details</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">developer_board</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">developer_mode</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">device_hub</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">devices</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">devices_other</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">dialer_sip</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">dialpad</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">directions</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">directions_bike</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">directions_boat</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">directions_bus</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">directions_car</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">directions_railway</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">directions_run</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">directions_subway</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">directions_transit</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">directions_walk</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">disc_full</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">dns</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">do_not_disturb</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">do_not_disturb_alt</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">do_not_disturb_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">do_not_disturb_on</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">dock</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">domain</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">done</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">done_all</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">donut_large</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">donut_small</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">drafts</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">drag_handle</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">drive_eta</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">dvr</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">edit</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">edit_location</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">eject</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">email</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">enhanced_encryption</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">equalizer</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">error</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">error_outline</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">euro_symbol</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">ev_station</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">event</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">event_available</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">event_busy</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">event_note</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">event_seat</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">exit_to_app</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">expand_less</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">expand_more</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">explicit</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">explore</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">exposure</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">exposure_neg_1</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">exposure_neg_2</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">exposure_plus_1</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">exposure_plus_2</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">exposure_zero</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">extension</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">face</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">fast_forward</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">fast_rewind</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">favorite</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">favorite_border</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">featured_play_list</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">featured_video</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">feedback</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">fiber_dvr</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">fiber_manual_record</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">fiber_new</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">fiber_pin</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">fiber_smart_record</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">file_download</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">file_upload</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">filter</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">filter_1</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">filter_2</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">filter_3</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">filter_4</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">filter_5</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">filter_6</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">filter_7</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">filter_8</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">filter_9</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">filter_9_plus</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">filter_b_and_w</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">filter_center_focus</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">filter_drama</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">filter_frames</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">filter_hdr</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">filter_list</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">filter_none</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">filter_tilt_shift</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">filter_vintage</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">find_in_page</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">find_replace</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">fingerprint</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">first_page</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">fitness_center</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">flag</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">flare</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">flash_auto</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">flash_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">flash_on</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">flight</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">flight_land</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">flight_takeoff</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">flip</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">flip_to_back</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">flip_to_front</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">folder</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">folder_open</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">folder_shared</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">folder_special</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">font_download</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_align_center</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_align_justify</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_align_left</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_align_right</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_bold</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_clear</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_color_fill</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_color_reset</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_color_text</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_indent_decrease</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_indent_increase</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_italic</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_line_spacing</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_list_bulleted</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_list_numbered</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_paint</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_quote</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_shapes</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_size</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_strikethrough</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_textdirection_l_to_r</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_textdirection_r_to_l</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">format_underlined</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">forum</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">forward</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">forward_10</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">forward_30</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">forward_5</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">free_breakfast</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">fullscreen</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">fullscreen_exit</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">functions</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">g_translate</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">gamepad</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">games</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">gavel</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">gesture</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">get_app</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">gif</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">golf_course</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">gps_fixed</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">gps_not_fixed</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">gps_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">grade</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">gradient</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">grain</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">graphic_eq</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">grid_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">grid_on</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">group</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">group_add</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">group_work</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">hd</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">hdr_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">hdr_on</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">hdr_strong</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">hdr_weak</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">headset</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">headset_mic</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">healing</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">hearing</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">help</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">help_outline</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">high_quality</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">highlight</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">highlight_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">history</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">home</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">hot_tub</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">hotel</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">hourglass_empty</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">hourglass_full</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">http</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">https</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">image</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">image_aspect_ratio</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">import_contacts</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">import_export</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">important_devices</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">inbox</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">indeterminate_check_box</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">info</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">info_outline</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">input</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">insert_chart</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">insert_comment</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">insert_drive_file</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">insert_emoticon</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">insert_invitation</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">insert_link</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">insert_photo</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">invert_colors</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">invert_colors_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">iso</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">keyboard</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">keyboard_arrow_down</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">keyboard_arrow_left</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">keyboard_arrow_right</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">keyboard_arrow_up</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">keyboard_backspace</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">keyboard_capslock</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">keyboard_hide</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">keyboard_return</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">keyboard_tab</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">keyboard_voice</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">kitchen</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">label</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">label_outline</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">landscape</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">language</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">laptop</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">laptop_chromebook</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">laptop_mac</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">laptop_windows</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">last_page</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">launch</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">layers</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">layers_clear</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">leak_add</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">leak_remove</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">lens</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">library_add</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">library_books</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">library_music</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">lightbulb_outline</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">line_style</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">line_weight</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">linear_scale</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">link</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">linked_camera</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">list</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">live_help</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">live_tv</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_activity</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_airport</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_atm</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_bar</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_cafe</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_car_wash</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_convenience_store</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_dining</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_drink</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_florist</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_gas_station</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_grocery_store</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_hospital</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_hotel</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_laundry_service</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_library</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_mall</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_movies</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_offer</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_parking</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_pharmacy</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_phone</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_pizza</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_play</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_post_office</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_printshop</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_see</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_shipping</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">local_taxi</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">location_city</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">location_disabled</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">location_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">location_on</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">location_searching</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">lock</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">lock_open</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">lock_outline</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">looks</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">looks_3</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">looks_4</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">looks_5</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">looks_6</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">looks_one</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">looks_two</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">loop</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">loupe</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">low_priority</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">loyalty</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">mail</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">mail_outline</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">map</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">markunread</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">markunread_mailbox</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">memory</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">menu</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">merge_type</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">message</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">mic</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">mic_none</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">mic_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">mms</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">mode_comment</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">mode_edit</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">monetization_on</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">money_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">monochrome_photos</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">mood</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">mood_bad</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">more</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">more_horiz</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">more_vert</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">motorcycle</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">mouse</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">move_to_inbox</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">movie</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">movie_creation</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">movie_filter</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">multiline_chart</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">music_note</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">music_video</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">my_location</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">nature</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">nature_people</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">navigate_before</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">navigate_next</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">navigation</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">near_me</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">network_cell</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">network_check</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">network_locked</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">network_wifi</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">new_releases</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">next_week</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">nfc</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">no_encryption</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">no_sim</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">not_interested</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">note</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">note_add</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">notifications</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">notifications_active</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">notifications_none</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">notifications_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">notifications_paused</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">offline_pin</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">ondemand_video</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">opacity</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">open_in_browser</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">open_in_new</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">open_with</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">pages</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">pageview</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">palette</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">pan_tool</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">panorama</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">panorama_fish_eye</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">panorama_horizontal</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">panorama_vertical</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">panorama_wide_angle</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">party_mode</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">pause</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">pause_circle_filled</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">pause_circle_outline</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">payment</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">people</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">people_outline</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">perm_camera_mic</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">perm_contact_calendar</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">perm_data_setting</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">perm_device_information</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">perm_identity</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">perm_media</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">perm_phone_msg</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">perm_scan_wifi</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">person</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">person_add</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">person_outline</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">person_pin</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">person_pin_circle</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">personal_video</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">pets</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">phone</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">phone_android</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">phone_bluetooth_speaker</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">phone_forwarded</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">phone_in_talk</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">phone_iphone</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">phone_locked</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">phone_missed</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">phone_paused</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">phonelink</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">phonelink_erase</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">phonelink_lock</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">phonelink_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">phonelink_ring</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">phonelink_setup</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">photo</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">photo_album</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">photo_camera</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">photo_filter</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">photo_library</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">photo_size_select_actual</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">photo_size_select_large</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">photo_size_select_small</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">picture_as_pdf</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">picture_in_picture</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">picture_in_picture_alt</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">pie_chart</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">pie_chart_outlined</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">pin_drop</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">place</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">play_arrow</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">play_circle_filled</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">play_circle_outline</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">play_for_work</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">playlist_add</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">playlist_add_check</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">playlist_play</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">plus_one</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">poll</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">polymer</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">pool</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">portable_wifi_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">portrait</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">power</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">power_input</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">power_settings_new</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">pregnant_woman</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">present_to_all</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">print</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">priority_high</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">public</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">publish</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">query_builder</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">question_answer</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">queue</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">queue_music</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">queue_play_next</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">radio</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">radio_button_checked</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">radio_button_unchecked</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">rate_review</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">receipt</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">recent_actors</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">record_voice_over</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">redeem</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">redo</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">refresh</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">remove</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">remove_circle</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">remove_circle_outline</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">remove_from_queue</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">remove_red_eye</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">remove_shopping_cart</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">reorder</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">repeat</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">repeat_one</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">replay</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">replay_10</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">replay_30</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">replay_5</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">reply</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">reply_all</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">report</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">report_problem</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">restaurant</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">restaurant_menu</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">restore</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">restore_page</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">ring_volume</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">room</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">room_service</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">rotate_90_degrees_ccw</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">rotate_left</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">rotate_right</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">rounded_corner</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">router</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">rowing</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">rss_feed</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">rv_hookup</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">satellite</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">save</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">scanner</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">schedule</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">school</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">screen_lock_landscape</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">screen_lock_portrait</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">screen_lock_rotation</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">screen_rotation</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">screen_share</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">sd_card</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">sd_storage</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">search</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">security</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">select_all</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">send</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">sentiment_dissatisfied</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">sentiment_neutral</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">sentiment_satisfied</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">sentiment_very_dissatisfied</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">sentiment_very_satisfied</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">settings</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">settings_applications</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">settings_backup_restore</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">settings_bluetooth</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">settings_brightness</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">settings_cell</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">settings_ethernet</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">settings_input_antenna</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">settings_input_component</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">settings_input_composite</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">settings_input_hdmi</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">settings_input_svideo</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">settings_overscan</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">settings_phone</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">settings_power</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">settings_remote</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">settings_system_daydream</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">settings_voice</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">share</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">shop</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">shop_two</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">shopping_basket</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">shopping_cart</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">short_text</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">show_chart</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">shuffle</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">signal_cellular_4_bar</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">signal_cellular_connected_no_internet_4_bar</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">signal_cellular_no_sim</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">signal_cellular_null</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">signal_cellular_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">signal_wifi_4_bar</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">signal_wifi_4_bar_lock</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">signal_wifi_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">sim_card</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">sim_card_alert</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">skip_next</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">skip_previous</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">slideshow</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">slow_motion_video</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">smartphone</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">smoke_free</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">smoking_rooms</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">sms</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">sms_failed</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">snooze</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">sort</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">sort_by_alpha</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">spa</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">space_bar</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">speaker</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">speaker_group</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">speaker_notes</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">speaker_notes_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">speaker_phone</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">spellcheck</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">star</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">star_border</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">star_half</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">stars</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">stay_current_landscape</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">stay_current_portrait</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">stay_primary_landscape</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">stay_primary_portrait</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">stop</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">stop_screen_share</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">storage</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">store</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">store_mall_directory</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">straighten</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">streetview</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">strikethrough_s</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">style</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">subdirectory_arrow_left</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">subdirectory_arrow_right</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">subject</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">subscriptions</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">subtitles</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">subway</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">supervisor_account</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">surround_sound</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">swap_calls</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">swap_horiz</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">swap_vert</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">swap_vertical_circle</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">switch_camera</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">switch_video</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">sync</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">sync_disabled</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">sync_problem</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">system_update</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">system_update_alt</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">tab</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">tab_unselected</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">tablet</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">tablet_android</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">tablet_mac</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">tag_faces</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">tap_and_play</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">terrain</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">text_fields</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">text_format</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">textsms</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">texture</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">theaters</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">thumb_down</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">thumb_up</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">thumbs_up_down</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">time_to_leave</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">timelapse</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">timeline</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">timer</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">timer_10</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">timer_3</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">timer_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">title</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">toc</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">today</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">toll</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">tonality</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">touch_app</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">toys</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">track_changes</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">traffic</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">train</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">tram</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">transfer_within_a_station</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">transform</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">translate</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">trending_down</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">trending_flat</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">trending_up</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">tune</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">turned_in</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">turned_in_not</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">tv</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">unarchive</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">undo</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">unfold_less</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">unfold_more</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">update</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">usb</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">verified_user</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">vertical_align_bottom</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">vertical_align_center</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">vertical_align_top</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">vibration</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">video_call</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">video_label</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">video_library</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">videocam</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">videocam_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">videogame_asset</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">view_agenda</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">view_array</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">view_carousel</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">view_column</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">view_comfy</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">view_compact</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">view_day</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">view_headline</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">view_list</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">view_module</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">view_quilt</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">view_stream</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">view_week</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">vignette</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">visibility</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">visibility_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">voice_chat</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">voicemail</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">volume_down</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">volume_mute</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">volume_off</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">volume_up</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">vpn_key</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">vpn_lock</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">wallpaper</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">warning</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">watch</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">watch_later</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">wb_auto</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">wb_cloudy</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">wb_incandescent</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">wb_iridescent</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">wb_sunny</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">wc</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">web</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">web_asset</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">weekend</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">whatshot</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">widgets</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">wifi</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">wifi_lock</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">wifi_tethering</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">work</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">wrap_text</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">youtube_searched_for</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">zoom_in</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">zoom_out</div>
          </div>
          <div class="ks-demo-icon col-33 tablet-15">
            <div class="icon"><i class="material-icons"></i></div>
            <div class="icon-name">zoom_out_map</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
