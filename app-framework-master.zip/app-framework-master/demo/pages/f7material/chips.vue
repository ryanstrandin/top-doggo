<template>
  <div data-page="chips" class="page kitchen-sink-material">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left"><a class="back link icon-only" href="#"><i class="icon icon-back"></i></a></div>
        <div class="center">Chips</div>
      </div>
    </div>
    <div class="page-content">
      <div class="content-block">
        <p>Chips represent complex entities in small blocks, such as a contact. They can contain a photo, short title string, and brief information.</p>
      </div>
      <div class="content-block-title">Chips With Text</div>
      <div class="content-block">
        <div class="chip">
          <div class="chip-label">Example Chip</div>
        </div>
        <div class="chip">
          <div class="chip-label">Another Chip</div>
        </div>
        <div class="chip">
          <div class="chip-label">One More Chip</div>
        </div>
        <div class="chip">
          <div class="chip-label">Fourth Chip</div>
        </div>
        <div class="chip">
          <div class="chip-label">Last One</div>
        </div>
      </div>
      <div class="content-block-title">Icon Chips</div>
      <div class="content-block">
        <div class="chip">
          <div class="chip-media bg-blue"><i class="icon material-icons"></i></div>
          <div class="chip-label">Set Date</div>
        </div>
        <div class="chip">
          <div class="chip-media bg-purple"><i class="icon material-icons"></i></div>
          <div class="chip-label">Sent</div>
        </div>
        <div class="chip">
          <div class="chip-media bg-red"><i class="icon material-icons"></i></div>
          <div class="chip-label">Uploaded</div>
        </div>
      </div>
      <div class="content-block-title">Contact Chips</div>
      <div class="content-block">
        <div class="chip">
          <div class="chip-media"><img src="http://lorempixel.com/100/100/people/9/"></div>
          <div class="chip-label">Jane Doe</div>
        </div>
        <div class="chip">
          <div class="chip-media"><img src="http://lorempixel.com/100/100/people/3/"></div>
          <div class="chip-label">John Doe</div>
        </div>
        <div class="chip">
          <div class="chip-media"><img src="http://lorempixel.com/100/100/people/7/"></div>
          <div class="chip-label">Adam Smith</div>
        </div>
        <div class="chip">
          <div class="chip-media bg-pink">J</div>
          <div class="chip-label">Jennifer</div>
        </div>
        <div class="chip">
          <div class="chip-media bg-teal">C</div>
          <div class="chip-label">Chris</div>
        </div>
        <div class="chip">
          <div class="chip-media bg-red">K</div>
          <div class="chip-label">Kate</div>
        </div>
      </div>
      <div class="content-block-title">Deletable Chips / Tags</div>
      <div class="content-block">
        <div class="chip">
          <div class="chip-label">Example Chip</div><a href="#" class="chip-delete"></a>
        </div>
        <div class="chip">
          <div class="chip-media bg-teal">C</div>
          <div class="chip-label">Chris</div><a href="#" class="chip-delete"></a>
        </div>
        <div class="chip">
          <div class="chip-media bg-purple"><i class="icon material-icons"></i></div>
          <div class="chip-label">Sent</div><a href="#" class="chip-delete"></a>
        </div>
        <div class="chip">
          <div class="chip-media"><img src="http://lorempixel.com/100/100/people/9/"></div>
          <div class="chip-label">Jane Doe</div><a href="#" class="chip-delete"></a>
        </div>
        <div class="chip">
          <div class="chip-label">One More Chip</div><a href="#" class="chip-delete"></a>
        </div>
        <div class="chip">
          <div class="chip-media bg-pink">J</div>
          <div class="chip-label">Jennifer</div><a href="#" class="chip-delete"></a>
        </div>
        <div class="chip">
          <div class="chip-media"><img src="http://lorempixel.com/100/100/people/7/"></div>
          <div class="chip-label">Adam Smith</div><a href="#" class="chip-delete"></a>
        </div>
        <div class="chip">
          <div class="chip-media bg-blue"><i class="icon material-icons"></i></div>
          <div class="chip-label">Set Date</div><a href="#" class="chip-delete"></a>
        </div>
      </div>
    </div>
  </div>
</template>
