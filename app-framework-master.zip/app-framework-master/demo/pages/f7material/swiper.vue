<template>
  <div data-page="swiper" class="page kitchen-sink-material">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left"><a class="back link icon-only" href="#"><i class="icon icon-back"></i></a></div>
        <div class="center">Swiper Slider</div>
      </div>
    </div>
    <div class="page-content">
      <div class="content-block">
        <p>Framework7 comes with powerful and most modern touch slider ever - <a href="http://idangero.us/swiper" class="external" target="_blank">Swiper Slider</a> with super flexible configuration and lot, lot of features. Just check the following demos:</p>
      </div>
      <div class="content-block-title">Swiper Examples</div>
      <div class="list-block">
        <ul>
          <li>
            <a href="/f7material/swiper-horizontal/" class="item-link item-content">
              <div class="item-inner">
                <div class="item-title">Swiper Horizontal</div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/swiper-vertical/" class="item-link item-content">
              <div class="item-inner">
                <div class="item-title">Swiper Vertical</div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/swiper-space-between/" class="item-link item-content">
              <div class="item-inner">
                <div class="item-title">Space Between Slides</div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/swiper-multiple/" class="item-link item-content">
              <div class="item-inner">
                <div class="item-title">Multiple Per Page</div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/swiper-nested/" class="item-link item-content">
              <div class="item-inner">
                <div class="item-title">Nested Swipers</div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/swiper-loop/" class="item-link item-content">
              <div class="item-inner">
                <div class="item-title">Infinite Loop Mode</div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/swiper-3d-cube/" class="item-link item-content">
              <div class="item-inner">
                <div class="item-title">3D Cube Effect</div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/swiper-3d-coverflow/" class="item-link item-content">
              <div class="item-inner">
                <div class="item-title">3D Coverflow Effect</div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/swiper-3d-flip/" class="item-link item-content">
              <div class="item-inner">
                <div class="item-title">3D Flip Effect</div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/swiper-fade/" class="item-link item-content">
              <div class="item-inner">
                <div class="item-title">Fade Effect</div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/swiper-scrollbar/" class="item-link item-content">
              <div class="item-inner">
                <div class="item-title">With Scrollbar</div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/swiper-gallery/" class="item-link item-content">
              <div class="item-inner">
                <div class="item-title">Two Way Control Gallery</div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/swiper-custom/" class="item-link item-content">
              <div class="item-inner">
                <div class="item-title">Custom Controls</div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/swiper-parallax/" class="item-link item-content">
              <div class="item-inner">
                <div class="item-title">Parallax</div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/swiper-pagination-progress/" class="item-link item-content">
              <div class="item-inner">
                <div class="item-title">Progress Pagination</div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/swiper-pagination-fraction/" class="item-link item-content">
              <div class="item-inner">
                <div class="item-title">Fraction Pagination</div>
              </div>
            </a>
          </li>
          <li>
            <a href="/f7material/swiper-zoom/" class="item-link item-content">
              <div class="item-inner">
                <div class="item-title">Zoom</div>
              </div>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
