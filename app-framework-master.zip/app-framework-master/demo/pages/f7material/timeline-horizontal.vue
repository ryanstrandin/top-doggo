<template>
  <div data-page="timeline-horizontal" class="page kitchen-sink-material">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left sliding"><a class="back link" href="#"><i class="icon icon-back"></i></a></div>
        <div class="center sliding">Horizontal Timeline</div>
      </div>
    </div>
    <div class="page-content">
      <div class="timeline timeline-horizontal">
        <div class="timeline-item">
          <div class="timeline-item-date">21 <small>DEC</small></div>
          <div class="timeline-item-content">
            <div class="timeline-item-inner">
              <div class="timeline-item-time">12:56</div>
              <div class="timeline-item-title">Title 1</div>
              <div class="timeline-item-subtitle">Subtitle 1</div>
              <div class="timeline-item-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit</div>
            </div>
            <div class="timeline-item-inner">
              <div class="timeline-item-time">13:15</div>
              <div class="timeline-item-title">Title 2</div>
              <div class="timeline-item-subtitle">Subtitle 2</div>
              <div class="timeline-item-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit</div>
            </div>
            <div class="timeline-item-inner">
              <div class="timeline-item-time">14:45</div>
              <div class="timeline-item-text">Do something</div>
            </div>
            <div class="timeline-item-inner">
              <div class="timeline-item-time">16:11</div>
              <div class="timeline-item-text">Do something else</div>
            </div>
          </div>
        </div>
        <div class="timeline-item">
          <div class="timeline-item-date">22 <small>DEC</small></div>
          <div class="timeline-item-content">Plain text goes here</div>
        </div>
        <div class="timeline-item">
          <div class="timeline-item-date">23 <small>DEC</small></div>
          <div class="timeline-item-content">
            <div class="card">
              <div class="card-header">Card</div>
              <div class="card-content">
                <div class="card-content-inner">Card Content</div>
              </div>
              <div class="card-footer">Card Footer</div>
            </div>
            <div class="card">
              <div class="card-content">
                <div class="card-content-inner">Another Card Content</div>
              </div>
            </div>
          </div>
        </div>
        <div class="timeline-item">
          <div class="timeline-item-date">24 <small>DEC</small></div>
          <div class="timeline-item-content">
            <div class="list-block inset">
              <ul>
                <li>
                  <a href="#" class="item-content item-link">
                    <div class="item-inner">
                      <div class="item-title">Item 1</div>
                    </div>
                  </a>
                </li>
                <li>
                  <a href="#" class="item-content item-link">
                    <div class="item-inner">
                      <div class="item-title">Item 1</div>
                    </div>
                  </a>
                </li>
                <li>
                  <a href="#" class="item-content item-link">
                    <div class="item-inner">
                      <div class="item-title">Item 1</div>
                    </div>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="timeline-item">
          <div class="timeline-item-date">25 <small>DEC</small></div>
          <div class="timeline-item-content">
            <div class="timeline-item-time">11:11</div>
            <div class="timeline-item-text">Task 1</div>
            <div class="timeline-item-time">12:33</div>
            <div class="timeline-item-text">Task 2</div>
            <div class="timeline-item-time">13:24</div>
            <div class="timeline-item-text">Task 3</div>
            <div class="timeline-item-time">14:55</div>
            <div class="timeline-item-text">Task 4</div>
            <div class="timeline-item-time">15:15</div>
            <div class="timeline-item-text">Task 5</div>
            <div class="timeline-item-time">16:54</div>
            <div class="timeline-item-text">Task 6</div>
          </div>
        </div>
        <div class="timeline-item">
          <div class="timeline-item-date">26 <small>DEC</small></div>
          <div class="timeline-item-content">
            <div class="timeline-item-inner">
              <div class="timeline-item-time">11:11</div>
              <div class="timeline-item-text">Task 1</div>
            </div>
            <div class="timeline-item-inner">
              <div class="timeline-item-time">12:33</div>
              <div class="timeline-item-text">Task 2</div>
            </div>
            <div class="timeline-item-inner">
              <div class="timeline-item-time">13:24</div>
              <div class="timeline-item-text">Task 3</div>
            </div>
            <div class="timeline-item-inner">
              <div class="timeline-item-time">14:55</div>
              <div class="timeline-item-text">Task 4</div>
            </div>
            <div class="timeline-item-inner">
              <div class="timeline-item-time">15:15</div>
              <div class="timeline-item-text">Task 5</div>
            </div>
            <div class="timeline-item-inner">
              <div class="timeline-item-time">16:54</div>
              <div class="timeline-item-text">Task 6</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
