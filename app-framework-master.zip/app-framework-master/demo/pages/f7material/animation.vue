<template>
  <div data-page="animation" class="page kitchen-sink-material">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left"><a class="back link icon-only" href="#"><i class="icon icon-back"></i></a></div>
        <div class="center">Animation</div>
      </div>
    </div>
    <div class="page-content">
      <div class="content-block">
        <p>Framework7 comes with own simple and fast animation helper library to create custom JS animations:</p>
        <p><a href="#" class="button start">Animate</a></p>
        <div id="animate-me" style="width:100px; height:100px" class="bg-red"></div>
      </div>
    </div>
  </div>
</template>
