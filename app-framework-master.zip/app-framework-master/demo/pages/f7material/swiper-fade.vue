<template>
  <div data-page="swiper-fade" class="page kitchen-sink-material">
    <div class="navbar">
      <div class="navbar-inner">
        <div class="left"><a class="back link icon-only" href="#"><i class="icon icon-back"></i></a></div>
        <div class="center">Fade Effect</div>
      </div>
    </div>
    <div class="page-content">
      <div data-pagination=".swiper-pagination" data-effect="fade" class="swiper-container swiper-init ks-demo-slider ks-fade-slider">
        <div class="swiper-pagination"></div>
        <div class="swiper-wrapper">
          <div style="background-image:url(http://lorempixel.com/1024/1024/people/1)" class="swiper-slide"></div>
          <div style="background-image:url(http://lorempixel.com/1024/1024/people/2)" class="swiper-slide"></div>
          <div style="background-image:url(http://lorempixel.com/1024/1024/people/3)" class="swiper-slide"></div>
          <div style="background-image:url(http://lorempixel.com/1024/1024/people/4)" class="swiper-slide"></div>
        </div>
      </div>
    </div>
  </div>
</template>
